
import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  ShoppingCart, Search, User, Menu, X, Heart, Sun, Moon, 
  LogOut, ChevronDown, ChevronRight, Facebook, Twitter, 
  Instagram, Youtube, History, Loader2
} from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { MOCK_PRODUCTS } from '../services/mockData';
import { FORMAT_CURRENCY, Product } from '../types';
import { AIChatAssistant } from './AIChatAssistant'; // Import the AI Assistant

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { cart, wishlist, user, logout, isDarkMode, toggleDarkMode, searchQuery, setSearchQuery } = useStore();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [filteredResults, setFilteredResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  
  const navigate = useNavigate();
  const location = useLocation();
  const searchRef = useRef<HTMLDivElement>(null);
  const mobileSearchRef = useRef<HTMLDivElement>(null);

  // Live Search Logic
  useEffect(() => {
    if (searchQuery.trim().length > 0) {
      setIsSearching(true);
      const timer = setTimeout(() => {
        const results = MOCK_PRODUCTS.filter(p => 
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.category.toLowerCase().includes(searchQuery.toLowerCase())
        ).slice(0, 6);
        setFilteredResults(results);
        setIsSearching(false);
        setShowResults(true);
      }, 150);
      return () => clearTimeout(timer);
    } else {
      setFilteredResults([]);
      setShowResults(false);
      setIsSearching(false);
    }
  }, [searchQuery]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node) && 
          mobileSearchRef.current && !mobileSearchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setShowResults(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEsc);
    };
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setShowResults(false);
      navigate('/product');
    }
  };

  const handleResultClick = (productId: string) => {
    setShowResults(false);
    navigate(`/product/${productId}`);
  };

  const SearchResultsDropdown = ({ results, searching }: { results: Product[], searching: boolean }) => (
    <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-gray-800 shadow-2xl rounded-xl border border-gray-100 dark:border-gray-700 overflow-hidden z-[100] animate-in fade-in slide-in-from-top-2 duration-200">
      <div className="p-3 border-b border-gray-50 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 flex justify-between items-center">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">
          {searching ? 'Searching...' : `Found ${results.length} Products`}
        </span>
        {searching && <Loader2 size={12} className="animate-spin text-brand-500" />}
      </div>
      
      {results.length > 0 ? (
        <div className="max-h-[400px] overflow-y-auto custom-scrollbar">
          {results.map(product => (
            <div 
              key={product.id} 
              onClick={() => handleResultClick(product.id)}
              className="flex items-center gap-4 p-3 hover:bg-brand-50/30 dark:hover:bg-brand-500/10 cursor-pointer transition-all border-b border-gray-50 dark:border-gray-700 last:border-none group"
            >
              <div className="w-14 h-14 rounded-lg bg-gray-50 dark:bg-gray-900 flex-shrink-0 overflow-hidden border border-gray-100 dark:border-gray-700 group-hover:border-brand-200">
                <img src={product.image} alt={product.name} className="w-full h-full object-contain p-1" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-semibold text-gray-800 dark:text-gray-200 truncate group-hover:text-brand-500 transition-colors">
                  {product.name}
                </h4>
                <p className="text-[10px] text-gray-400 uppercase font-medium mb-1">{product.category}</p>
                <div className="flex items-center gap-2">
                  <span className="text-brand-500 font-bold text-sm">{FORMAT_CURRENCY(product.price)}</span>
                  {product.originalPrice && (
                    <span className="text-gray-400 text-xs line-through">{FORMAT_CURRENCY(product.originalPrice)}</span>
                  )}
                </div>
              </div>
              <ChevronRight size={16} className="text-gray-300 group-hover:text-brand-500 transition-colors transform group-hover:translate-x-1" />
            </div>
          ))}
          <div 
            onClick={handleSearchSubmit}
            className="p-3 text-center bg-gray-50 dark:bg-gray-900 hover:bg-brand-500 hover:text-white text-brand-500 dark:text-brand-400 hover:dark:text-white text-xs font-bold cursor-pointer transition-all uppercase tracking-wider flex items-center justify-center gap-2"
          >
            See All Results for "{searchQuery}" <ArrowRight size={14} />
          </div>
        </div>
      ) : !searching && (
        <div className="p-10 text-center">
          <Search size={32} className="mx-auto text-gray-200 mb-2" />
          <p className="text-gray-500 text-sm font-medium">No products found for "{searchQuery}"</p>
          <p className="text-gray-400 text-xs mt-1">Try checking for typos or use more general terms.</p>
        </div>
      )}
    </div>
  );

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-200 ${isDarkMode ? 'dark bg-gray-900 text-white' : 'bg-gray-50'}`}>
      
      {/* Top Bar */}
      <div className="bg-gray-100 dark:bg-gray-800 py-1.5 text-xs border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 flex justify-between items-center text-gray-600 dark:text-gray-400">
          <div className="flex gap-6 font-medium">
            <span className="cursor-pointer hover:text-brand-500 transition-colors">Become a Seller</span>
            <span className="cursor-pointer hover:text-brand-500 transition-colors">Help & Support</span>
          </div>
          <div className="flex gap-6 items-center">
            <button onClick={toggleDarkMode} className="flex items-center gap-2 hover:text-brand-500 transition-colors font-medium">
              {isDarkMode ? <Sun size={14} /> : <Moon size={14} />}
              {isDarkMode ? 'Light Mode' : 'Dark Mode'}
            </button>
            <span className="cursor-pointer hover:text-brand-500 transition-colors font-medium">Track Order</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="sticky top-0 z-50 bg-white dark:bg-gray-900 shadow-md border-b border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-4 py-3 md:py-4">
          <div className="flex items-center justify-between gap-4 lg:gap-8">
            
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 flex-shrink-0 group">
              <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-brand-500/30 group-hover:scale-105 transition-transform">M</div>
              <div className="hidden sm:block">
                <span className="text-2xl font-black text-brand-500 tracking-tighter italic">MEGA</span>
                <span className="text-2xl font-light text-gray-800 dark:text-white tracking-tight">THEME</span>
              </div>
            </Link>

            {/* Desktop Search Bar */}
            <div ref={searchRef} className="flex-1 max-w-2xl hidden md:block relative">
              <form onSubmit={handleSearchSubmit} className="flex relative shadow-sm group">
                <input
                  type="text"
                  placeholder="What are you looking for today?..."
                  className="w-full pl-5 pr-12 py-3 bg-gray-50 dark:bg-gray-800 border-2 border-transparent focus:border-brand-500 dark:focus:border-brand-500 rounded-xl focus:ring-4 focus:ring-brand-500/10 outline-none transition-all dark:text-white"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => searchQuery.trim().length > 0 && setShowResults(true)}
                />
                <button type="submit" className="absolute right-1 top-1 bottom-1 bg-brand-500 hover:bg-brand-600 text-white px-5 rounded-lg transition-all flex items-center justify-center shadow-lg shadow-brand-500/20 active:scale-95">
                  <Search size={20} />
                </button>
              </form>

              {/* Live Search Results Dropdown */}
              {showResults && (
                <SearchResultsDropdown results={filteredResults} searching={isSearching} />
              )}
            </div>

            {/* Header Actions */}
            <div className="flex items-center gap-1 sm:gap-4">
              {user ? (
                <div className="flex items-center gap-2 cursor-pointer group relative p-1.5 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-xl transition-colors">
                  <div className="w-9 h-9 rounded-lg border-2 border-brand-500 p-0.5">
                    <img src={user.avatar} alt="User" className="w-full h-full rounded-md object-cover" />
                  </div>
                  <div className="hidden lg:block text-left mr-1">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest leading-none mb-1">Account</p>
                    <p className="font-bold text-sm text-gray-800 dark:text-gray-200 leading-none">{user.name.split(' ')[0]}</p>
                  </div>
                  <ChevronDown size={14} className="text-gray-400 group-hover:rotate-180 transition-transform" />
                  
                  {/* Account Dropdown */}
                  <div className="absolute top-full right-0 mt-2 w-56 bg-white dark:bg-gray-800 shadow-2xl rounded-xl py-3 hidden group-hover:block border border-gray-100 dark:border-gray-700 animate-in fade-in zoom-in-95 duration-200">
                     <div className="px-4 py-2 border-b border-gray-50 dark:border-gray-700 mb-2">
                       <p className="font-bold text-gray-800 dark:text-white">{user.name}</p>
                       <p className="text-xs text-gray-400 truncate">{user.email}</p>
                     </div>
                     <Link to="/profile" className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-600 dark:text-gray-300 hover:bg-brand-50 dark:hover:bg-brand-500/10 hover:text-brand-500 transition-colors">
                        <User size={16} /> My Profile
                     </Link>
                     <Link to="/orders" className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-600 dark:text-gray-300 hover:bg-brand-50 dark:hover:bg-brand-500/10 hover:text-brand-500 transition-colors">
                        <History size={16} /> Order History
                     </Link>
                     <div className="h-px bg-gray-50 dark:bg-gray-700 my-2"></div>
                     <button onClick={logout} className="w-full text-left px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 flex items-center gap-3 font-bold transition-colors">
                       <LogOut size={16} /> Logout
                     </button>
                  </div>
                </div>
              ) : (
                <Link to="/login" className="flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-gray-800 p-2 rounded-xl transition-all group">
                  <div className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-xl flex items-center justify-center group-hover:bg-brand-50 transition-colors">
                    <User size={22} className="text-gray-500 dark:text-gray-400 group-hover:text-brand-500" />
                  </div>
                  <div className="hidden lg:block text-left">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest leading-none mb-1">Hello, Sign in</p>
                    <p className="font-bold text-sm text-gray-800 dark:text-gray-200 leading-none">Account & Lists</p>
                  </div>
                </Link>
              )}

              {/* Wishlist */}
              <div className="relative p-2.5 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-xl transition-all cursor-pointer group">
                 <Heart size={24} className="text-gray-600 dark:text-gray-300 group-hover:text-brand-500 group-hover:fill-brand-500" />
                 {wishlist.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 bg-brand-500 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white dark:border-gray-900 shadow-md animate-bounce">
                    {wishlist.length}
                  </span>
                )}
              </div>

              {/* Cart */}
              <Link to="/cart" className="relative p-2.5 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-xl transition-all group">
                <ShoppingCart size={24} className="text-gray-600 dark:text-gray-300 group-hover:text-brand-500" />
                {cart.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 bg-brand-500 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white dark:border-gray-900 shadow-md">
                    {cart.reduce((a, b) => a + b.quantity, 0)}
                  </span>
                )}
              </Link>

              {/* Mobile Menu Toggle */}
              <button className="md:hidden p-2.5 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition-colors" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
                {isMobileMenuOpen ? <X size={26} className="text-brand-500" /> : <Menu size={26} />}
              </button>
            </div>
          </div>

          {/* Mobile Search Bar */}
          <div ref={mobileSearchRef} className="md:hidden mt-3 pb-1 relative">
             <div className="relative group">
                <input 
                  type="text" 
                  placeholder="Search products..." 
                  className="w-full pl-5 pr-12 py-2.5 bg-gray-100 dark:bg-gray-800 rounded-xl outline-none border-2 border-transparent focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10 transition-all"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => searchQuery.trim().length > 0 && setShowResults(true)}
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                  <Search size={20} />
                </div>
             </div>
             {/* Live Search Results Mobile */}
             {showResults && (
                <SearchResultsDropdown results={filteredResults} searching={isSearching} />
             )}
          </div>
        </div>

        {/* Categories / Navigation Strip */}
        <div className="hidden lg:block border-t border-gray-100 dark:border-gray-800">
            <div className="container mx-auto px-4">
                <div className="flex items-center justify-between h-12">
                    {/* Categories Toggle */}
                    <div className="flex items-center gap-3 cursor-pointer group pr-8 border-r border-gray-100 dark:border-gray-800 h-full min-w-[220px] bg-brand-500 text-white px-4 hover:bg-brand-600 transition-colors rounded-t-lg mt-1">
                        <Menu size={20} />
                        <span className="font-bold text-xs tracking-widest uppercase">Categories</span>
                        <ChevronDown size={14} className="ml-auto opacity-70" />
                    </div>

                    {/* Nav Links */}
                    <nav className="flex items-center gap-10 flex-1 pl-10">
                        <Link to="/" className={`text-xs font-black tracking-widest transition-colors ${location.pathname === '/' ? 'text-brand-500 underline underline-offset-8 decoration-2' : 'text-gray-800 dark:text-gray-200 hover:text-brand-500'}`}>HOME</Link>
                        <Link to="/product" className={`text-xs font-black tracking-widest transition-colors ${location.pathname === '/product' ? 'text-brand-500 underline underline-offset-8 decoration-2' : 'text-gray-800 dark:text-gray-200 hover:text-brand-500'}`}>SHOP</Link>
                        <div className="relative group cursor-pointer text-xs font-black tracking-widest text-gray-800 dark:text-gray-200 hover:text-brand-500 transition-colors flex items-center gap-1">
                            FLASH DEALS <span className="bg-brand-500 text-[8px] text-white px-1 rounded animate-pulse">HOT</span>
                        </div>
                        <Link to="/" className="text-xs font-black tracking-widest text-gray-800 dark:text-gray-200 hover:text-brand-500 transition-colors">ABOUT</Link>
                        <Link to="/" className="text-xs font-black tracking-widest text-gray-800 dark:text-gray-200 hover:text-brand-500 transition-colors">CONTACT</Link>
                    </nav>

                    {/* Right Info */}
                    <div className="flex items-center gap-8 text-[11px] font-bold text-gray-500 uppercase tracking-widest">
                        <div className="flex items-center gap-2 group cursor-pointer hover:text-brand-500 transition-colors">
                            <span className="text-lg">🇺🇸</span>
                            <span>USD</span>
                            <ChevronDown size={12} className="group-hover:rotate-180 transition-transform" />
                        </div>
                        <div className="flex items-center gap-2 text-brand-500">
                          <Facebook size={14} className="cursor-pointer hover:scale-110 transition-transform" />
                          <Instagram size={14} className="cursor-pointer hover:scale-110 transition-transform" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* AI Chat Assistant */}
      <AIChatAssistant />

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 pt-16 pb-8 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div className="space-y-6">
              <Link to="/" className="flex items-center gap-2 group">
                <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center text-white font-bold text-lg">M</div>
                <span className="text-xl font-black text-brand-500 tracking-tighter italic">MEGA</span>
              </Link>
              <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">
                Experience the next generation of online shopping with Mega Theme. We provide high-quality products with unbeatable service and global shipping.
              </p>
              <div className="flex gap-4">
                {[Facebook, Twitter, Instagram, Youtube].map((Icon, i) => (
                  <div key={i} className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-brand-500 hover:text-white transition-all cursor-pointer">
                    <Icon size={18} />
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-black text-xs uppercase tracking-[0.2em] text-gray-900 dark:text-white mb-8 border-l-4 border-brand-500 pl-4">Customer Care</h4>
              <ul className="space-y-4 text-sm text-gray-500 dark:text-gray-400">
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Help Center</li>
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Track Your Order</li>
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Corporate & Bulk Purchasing</li>
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Returns & Refunds</li>
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Contact Us</li>
              </ul>
            </div>

            <div>
              <h4 className="font-black text-xs uppercase tracking-[0.2em] text-gray-900 dark:text-white mb-8 border-l-4 border-brand-500 pl-4">Mega Theme</h4>
              <ul className="space-y-4 text-sm text-gray-500 dark:text-gray-400">
                <li className="hover:text-brand-500 cursor-pointer transition-colors">About Us</li>
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Digital Payments</li>
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Mega Blog</li>
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Careers</li>
                <li className="hover:text-brand-500 cursor-pointer transition-colors">Terms & Conditions</li>
              </ul>
            </div>

            <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-100 dark:border-gray-700">
              <h4 className="font-black text-xs uppercase tracking-[0.2em] text-gray-900 dark:text-white mb-6">Exclusive App</h4>
              <div className="flex flex-col gap-4">
                 <div className="bg-black text-white px-4 py-2.5 rounded-xl flex items-center gap-3 cursor-pointer hover:scale-105 transition-transform shadow-lg">
                    <div className="w-6 h-6 rounded bg-white/20"></div>
                    <div>
                      <p className="text-[8px] uppercase font-bold leading-none">Download on the</p>
                      <p className="text-sm font-bold leading-none mt-0.5">App Store</p>
                    </div>
                 </div>
                 <div className="bg-black text-white px-4 py-2.5 rounded-xl flex items-center gap-3 cursor-pointer hover:scale-105 transition-transform shadow-lg">
                    <div className="w-6 h-6 rounded bg-white/20"></div>
                    <div>
                      <p className="text-[8px] uppercase font-bold leading-none">Get it on</p>
                      <p className="text-sm font-bold leading-none mt-0.5">Google Play</p>
                    </div>
                 </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-50 dark:border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
            <p>&copy; 2024 Mega Theme Store. Built for the modern world.</p>
            <div className="flex gap-8">
               <span className="cursor-pointer hover:text-brand-500 transition-colors">Privacy Policy</span>
               <span className="cursor-pointer hover:text-brand-500 transition-colors">Terms of Service</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-[100] md:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="absolute top-0 left-0 bottom-0 w-[280px] bg-white dark:bg-gray-900 animate-in slide-in-from-left duration-300">
            <div className="p-6 bg-brand-500 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center font-bold">M</div>
                <span className="font-black italic">MEGA MOBILE</span>
              </div>
              <X size={24} onClick={() => setIsMobileMenuOpen(false)} className="cursor-pointer" />
            </div>
            <div className="p-6 space-y-6">
               <nav className="flex flex-col gap-6 font-black uppercase tracking-widest text-sm text-gray-800 dark:text-gray-200">
                  <Link to="/" onClick={() => setIsMobileMenuOpen(false)}>Home</Link>
                  <Link to="/product" onClick={() => setIsMobileMenuOpen(false)}>Shop</Link>
                  <Link to="/cart" onClick={() => setIsMobileMenuOpen(false)}>Cart</Link>
                  <Link to="/wishlist" onClick={() => setIsMobileMenuOpen(false)}>Wishlist</Link>
               </nav>
               <div className="h-px bg-gray-100 dark:bg-gray-800 my-6"></div>
               {user ? (
                 <button onClick={() => { logout(); setIsMobileMenuOpen(false); }} className="text-red-500 font-bold uppercase tracking-widest text-xs flex items-center gap-2">
                   <LogOut size={16} /> Logout
                 </button>
               ) : (
                 <Link to="/login" onClick={() => setIsMobileMenuOpen(false)} className="bg-brand-500 text-white px-6 py-3 rounded-xl font-bold uppercase tracking-widest text-xs inline-block text-center w-full">
                    Login / Sign up
                 </Link>
               )}
            </div>
          </div>
        </div>
      )}

      {/* Custom Global Styles */}
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #ff405644;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #ff4056;
        }
      `}</style>
    </div>
  );
};

const ArrowRight = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
);
