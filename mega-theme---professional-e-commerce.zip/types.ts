export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  discount: number;
  rating: number;
  reviews: number;
  image: string;
  category: string;
  isFlashSale?: boolean;
  description: string;
  stock: number;
  specs: Record<string, string>;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'admin';
  avatar?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: any; // Lucide Icon
}

export type ViewState = 'HOME' | 'PRODUCT_DETAIL' | 'CART' | 'LOGIN' | 'ADMIN';

export const FORMAT_CURRENCY = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
  }).format(amount);
};