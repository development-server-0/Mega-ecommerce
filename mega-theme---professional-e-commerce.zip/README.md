
# 🚀 Mega Theme - Vercel Deployment Guide

Follow these steps to host your professional Daraz-like e-commerce website on Vercel.

## Step 1: Push to GitHub
1. Create a new repository on [GitHub](https://github.com/new).
2. Initialize your local folder as a git repo:
   ```bash
   git init
   git add .
   git commit -m "feat: initial ecommerce release"
   git remote add origin YOUR_GITHUB_REPO_URL
   git push -u origin main
   ```

## Step 2: Connect to Vercel
1. Log in to [Vercel](https://vercel.com).
2. Click **"Add New"** -> **"Project"**.
3. Import your `mega-theme` repository from GitHub.

## Step 3: Configure Settings
1. **Framework Preset**: Select **"Other"**.
2. **Build and Output Settings**: 
   - Vercel automatically detects static projects. You can leave the build command empty.
3. **Environment Variables**:
   - Add a key named `API_KEY`.
   - Paste your Google Gemini API key as the value (required for future AI features).

## Step 4: Deploy
1. Click **"Deploy"**.
2. Within seconds, your site will be live on a `*.vercel.app` domain!

## Why Vercel?
- **Global CDN**: Your site loads instantly from anywhere in the world.
- **Auto-SSL**: Free HTTPS is configured automatically.
- **Continuous Deployment**: Every time you push to GitHub, your site updates automatically.
