
import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';

export const ResetPassword = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const { resetPassword } = useStore();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      resetPassword(email);
      setSubmitted(true);
    }
  };

  if (submitted) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="bg-white dark:bg-gray-800 p-10 rounded-2xl shadow-xl w-full max-w-md border border-gray-100 dark:border-gray-700 text-center">
            <div className="w-16 h-16 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={32} />
            </div>
            <h2 className="text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tight mb-4">Check Your Inbox</h2>
            <p className="text-gray-500 mb-8 leading-relaxed">
              We've sent password reset instructions to <span className="font-bold text-gray-800 dark:text-gray-200">{email}</span>. 
              Please follow the link in the email to reset your password.
            </p>
            <Link to="/login" className="inline-flex items-center gap-2 text-brand-500 font-bold hover:underline uppercase tracking-wider text-xs">
              <ArrowLeft size={14} /> Back to Login
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl w-full max-w-md border border-gray-100 dark:border-gray-700">
          <div className="text-center mb-8">
            <div className="w-12 h-12 bg-brand-50 text-brand-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail size={24} />
            </div>
            <h2 className="text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tight">Reset Password</h2>
            <p className="text-gray-500 text-sm mt-2">Enter your email and we'll send you a link to reset your password.</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Email Address</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-transparent transition-all"
                placeholder="email@example.com"
              />
            </div>

            <button 
              type="submit" 
              className="w-full bg-brand-500 text-white py-4 rounded-xl font-bold hover:bg-brand-600 transition-all shadow-lg active:scale-[0.98] uppercase tracking-wider text-sm"
            >
              Send Reset Link
            </button>
          </form>

          <div className="mt-8 text-center pt-6 border-t border-gray-100 dark:border-gray-700">
            <Link to="/login" className="inline-flex items-center gap-2 text-brand-500 font-bold hover:underline uppercase tracking-wider text-xs">
              <ArrowLeft size={14} /> Back to Login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
