
import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { FORMAT_CURRENCY } from '../types';
import { 
  ChevronRight, CreditCard, Truck, Globe, MapPin, 
  CheckCircle2, AlertCircle, ShieldCheck, DollarSign,
  Info, Bitcoin, Smartphone
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ShippingProvider {
  id: string;
  name: string;
  cost: number;
  time: string;
  logo: string;
}

const DOMESTIC_PROVIDERS: ShippingProvider[] = [
  { id: 'standard', name: 'Standard Local Delivery', cost: 120, time: '3-5 Business Days', logo: '🚚' },
  { id: 'express', name: 'Express One-Day', cost: 350, time: '24 Hours Delivery', logo: '⚡' },
];

const INTERNATIONAL_PROVIDERS: ShippingProvider[] = [
  { id: 'dhl', name: 'DHL Express Worldwide', cost: 4500, time: '2-3 Business Days', logo: '✈️' },
  { id: 'fedex', name: 'FedEx International Priority', cost: 3800, time: '3-5 Business Days', logo: '📦' },
  { id: 'ups', name: 'UPS Worldwide Saver', cost: 3600, time: '4-6 Business Days', logo: '🏢' },
  { id: 'aramex', name: 'Aramex Global Logsitics', cost: 2800, time: '7-10 Business Days', logo: '🌍' },
];

const COUNTRIES = [
  'United States', 'United Kingdom', 'Canada', 'Australia', 'Germany', 
  'France', 'Japan', 'United Arab Emirates', 'Singapore', 'India', 'Bangladesh'
];

export const Checkout = () => {
  const { cart, cartTotal, user } = useStore();
  const navigate = useNavigate();
  
  const [shippingType, setShippingType] = useState<'domestic' | 'international'>('domestic');
  const [selectedProvider, setSelectedProvider] = useState<ShippingProvider>(DOMESTIC_PROVIDERS[0]);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'stripe' | 'crypto' | 'cod'>('card');
  const [selectedCountry, setSelectedCountry] = useState('United States');

  if (cart.length === 0) {
    navigate('/cart');
    return null;
  }

  const handleShippingTypeChange = (type: 'domestic' | 'international') => {
    setShippingType(type);
    setSelectedProvider(type === 'domestic' ? DOMESTIC_PROVIDERS[0] : INTERNATIONAL_PROVIDERS[0]);
  };

  const finalTotal = cartTotal + selectedProvider.cost;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-8">
         <h1 className="text-3xl font-black text-gray-900 dark:text-white uppercase tracking-tight">Checkout</h1>
         <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700"></div>
         <div className="flex items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-widest">
            <span className="text-brand-500">Cart</span>
            <ChevronRight size={14} />
            <span className="text-brand-500">Checkout</span>
            <ChevronRight size={14} />
            <span>Success</span>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Main Content Area */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* Shipping Address Section */}
          <section className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
            <div className="flex items-center gap-3 mb-6">
               <div className="w-10 h-10 bg-brand-50 text-brand-500 rounded-xl flex items-center justify-center">
                  <MapPin size={22} />
               </div>
               <h2 className="text-xl font-bold">Shipping Information</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Full Name</label>
                <input type="text" defaultValue={user?.name || ''} placeholder="John Doe" className="w-full bg-gray-50 dark:bg-gray-900 border border-transparent focus:border-brand-500 rounded-xl px-4 py-3 outline-none transition-all" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Email Address</label>
                <input type="email" defaultValue={user?.email || ''} placeholder="email@example.com" className="w-full bg-gray-50 dark:bg-gray-900 border border-transparent focus:border-brand-500 rounded-xl px-4 py-3 outline-none transition-all" />
              </div>
              <div className="md:col-span-2 space-y-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Street Address</label>
                <input type="text" placeholder="123 Shopping Avenue, Store District" className="w-full bg-gray-50 dark:bg-gray-900 border border-transparent focus:border-brand-500 rounded-xl px-4 py-3 outline-none transition-all" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">City / Region</label>
                <input type="text" placeholder="New York" className="w-full bg-gray-50 dark:bg-gray-900 border border-transparent focus:border-brand-500 rounded-xl px-4 py-3 outline-none transition-all" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">ZIP / Postcode</label>
                <input type="text" placeholder="10001" className="w-full bg-gray-50 dark:bg-gray-900 border border-transparent focus:border-brand-500 rounded-xl px-4 py-3 outline-none transition-all" />
              </div>
            </div>
          </section>

          {/* Delivery Method Selection */}
          <section className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
            <div className="flex items-center justify-between mb-8">
               <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-50 text-brand-500 rounded-xl flex items-center justify-center">
                      <Truck size={22} />
                  </div>
                  <h2 className="text-xl font-bold">Delivery Method</h2>
               </div>
               
               <div className="flex p-1 bg-gray-50 dark:bg-gray-900 rounded-xl">
                  <button 
                    onClick={() => handleShippingTypeChange('domestic')}
                    className={`px-4 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${shippingType === 'domestic' ? 'bg-brand-500 text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
                  >
                    Domestic
                  </button>
                  <button 
                    onClick={() => handleShippingTypeChange('international')}
                    className={`px-4 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${shippingType === 'international' ? 'bg-brand-500 text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
                  >
                    International
                  </button>
               </div>
            </div>

            {shippingType === 'international' && (
               <div className="mb-6 animate-in fade-in slide-in-from-top-2 duration-300">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2 block">Destination Country</label>
                  <div className="relative">
                    <Globe size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                    <select 
                      value={selectedCountry}
                      onChange={(e) => setSelectedCountry(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50 dark:bg-gray-900 border border-transparent focus:border-brand-500 rounded-xl outline-none appearance-none cursor-pointer"
                    >
                      {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
               </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(shippingType === 'domestic' ? DOMESTIC_PROVIDERS : INTERNATIONAL_PROVIDERS).map(provider => (
                <div 
                  key={provider.id}
                  onClick={() => setSelectedProvider(provider)}
                  className={`relative p-5 rounded-2xl border-2 transition-all cursor-pointer group ${selectedProvider.id === provider.id ? 'border-brand-500 bg-brand-50/20 dark:bg-brand-500/10' : 'border-gray-50 dark:border-gray-700 hover:border-brand-200'}`}
                >
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-3xl">{provider.logo}</span>
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${selectedProvider.id === provider.id ? 'bg-brand-500 border-brand-500' : 'border-gray-200 dark:border-gray-600'}`}>
                      {selectedProvider.id === provider.id && <CheckCircle2 size={16} className="text-white" />}
                    </div>
                  </div>
                  <h3 className="font-bold text-gray-900 dark:text-white mb-1 group-hover:text-brand-500 transition-colors">{provider.name}</h3>
                  <div className="flex justify-between items-end">
                    <p className="text-xs text-gray-500 font-medium italic">{provider.time}</p>
                    <span className="text-sm font-black text-brand-500">{FORMAT_CURRENCY(provider.cost)}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* International Payment Methods Selection */}
          <section className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
            <div className="flex items-center gap-3 mb-8">
               <div className="w-10 h-10 bg-brand-50 text-brand-500 rounded-xl flex items-center justify-center">
                  <CreditCard size={22} />
               </div>
               <h2 className="text-xl font-bold">Payment Methods</h2>
            </div>

            <div className="space-y-4">
              {/* Payment Option: Credit Card */}
              <div 
                onClick={() => setPaymentMethod('card')}
                className={`p-4 rounded-xl border-2 flex items-center gap-4 cursor-pointer transition-all ${paymentMethod === 'card' ? 'border-brand-500 bg-brand-50/20 dark:bg-brand-500/10' : 'border-gray-100 dark:border-gray-700 hover:border-brand-100'}`}
              >
                <div className="w-10 h-10 bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center text-gray-600"><CreditCard size={20} /></div>
                <div className="flex-1">
                  <p className="font-bold text-sm">International Credit / Debit Card</p>
                  <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest mt-0.5">Visa, Mastercard, Amex, Discover</p>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'card' ? 'bg-brand-500 border-brand-500' : 'border-gray-200'}`}>
                  {paymentMethod === 'card' && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                </div>
              </div>

              {/* Payment Option: PayPal */}
              <div 
                onClick={() => setPaymentMethod('paypal')}
                className={`p-4 rounded-xl border-2 flex items-center gap-4 cursor-pointer transition-all ${paymentMethod === 'paypal' ? 'border-brand-500 bg-brand-50/20 dark:bg-brand-500/10' : 'border-gray-100 dark:border-gray-700 hover:border-brand-100'}`}
              >
                <div className="w-10 h-10 bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center text-blue-600"><Smartphone size={20} /></div>
                <div className="flex-1">
                  <p className="font-bold text-sm">PayPal Checkout</p>
                  <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest mt-0.5">Pay via balance or linked bank accounts</p>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'paypal' ? 'bg-brand-500 border-brand-500' : 'border-gray-200'}`}>
                  {paymentMethod === 'paypal' && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                </div>
              </div>

              {/* Payment Option: Crypto */}
              <div 
                onClick={() => setPaymentMethod('crypto')}
                className={`p-4 rounded-xl border-2 flex items-center gap-4 cursor-pointer transition-all ${paymentMethod === 'crypto' ? 'border-brand-500 bg-brand-50/20 dark:bg-brand-500/10' : 'border-gray-100 dark:border-gray-700 hover:border-brand-100'}`}
              >
                <div className="w-10 h-10 bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center text-orange-500"><Bitcoin size={20} /></div>
                <div className="flex-1">
                  <p className="font-bold text-sm">Cryptocurrency Payment</p>
                  <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest mt-0.5">BTC, ETH, USDT, SOL (via BitPay)</p>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'crypto' ? 'bg-brand-500 border-brand-500' : 'border-gray-200'}`}>
                  {paymentMethod === 'crypto' && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                </div>
              </div>

              {/* Card Details (Conditional Rendering) */}
              {paymentMethod === 'card' && (
                <div className="p-6 bg-gray-50 dark:bg-gray-900 rounded-2xl space-y-4 border border-gray-100 dark:border-gray-700 mt-4 animate-in zoom-in-95 duration-200">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Card Number</label>
                    <div className="relative">
                       <CreditCard size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                       <input type="text" placeholder="0000 0000 0000 0000" className="w-full pl-12 pr-4 py-3 bg-white dark:bg-gray-800 border-2 border-transparent focus:border-brand-500 rounded-xl outline-none transition-all font-mono" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Expiry Date</label>
                      <input type="text" placeholder="MM / YY" className="w-full px-4 py-3 bg-white dark:bg-gray-800 border-2 border-transparent focus:border-brand-500 rounded-xl outline-none transition-all font-mono" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">CVV</label>
                      <input type="password" placeholder="•••" maxLength={3} className="w-full px-4 py-3 bg-white dark:bg-gray-800 border-2 border-transparent focus:border-brand-500 rounded-xl outline-none transition-all font-mono" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </section>
        </div>

        {/* Sidebar Order Summary */}
        <div className="lg:col-span-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-700 overflow-hidden sticky top-24">
            <div className="p-6 bg-gray-50 dark:bg-gray-900 border-b border-gray-100 dark:border-gray-700">
               <h2 className="text-xl font-bold">Order Summary</h2>
            </div>
            
            <div className="p-6 space-y-4">
               {cart.map(item => (
                 <div key={item.id} className="flex gap-4">
                    <div className="w-16 h-16 bg-gray-100 dark:bg-gray-900 rounded-xl flex-shrink-0 overflow-hidden p-2 border border-gray-50 dark:border-gray-700">
                       <img src={item.image} alt={item.name} className="w-full h-full object-contain" />
                    </div>
                    <div className="flex-1 min-w-0">
                       <h4 className="text-sm font-bold truncate">{item.name}</h4>
                       <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest mt-1">Qty: {item.quantity}</p>
                       <p className="text-sm font-black text-brand-500 mt-1">{FORMAT_CURRENCY(item.price * item.quantity)}</p>
                    </div>
                 </div>
               ))}
               
               <div className="pt-6 border-t border-dashed border-gray-200 dark:border-gray-700 space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 font-medium">Subtotal</span>
                    <span className="font-bold text-gray-900 dark:text-white">{FORMAT_CURRENCY(cartTotal)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 font-medium">Shipping ({selectedProvider.name})</span>
                    <span className="font-bold text-brand-500">+{FORMAT_CURRENCY(selectedProvider.cost)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 font-medium">Est. Duties & Taxes</span>
                    <span className="font-bold text-gray-900 dark:text-white">{FORMAT_CURRENCY(0)}</span>
                  </div>
               </div>

               <div className="pt-6 border-t-2 border-gray-100 dark:border-gray-700">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-lg font-black uppercase tracking-tight">Order Total</span>
                    <span className="text-2xl font-black text-brand-500">{FORMAT_CURRENCY(finalTotal)}</span>
                  </div>
                  
                  <button className="w-full bg-brand-500 hover:bg-brand-600 text-white py-4 rounded-2xl font-black uppercase tracking-[0.2em] text-sm shadow-xl shadow-brand-500/30 transition-all transform active:scale-95 flex items-center justify-center gap-3">
                    Complete Purchase <CheckCircle2 size={18} />
                  </button>
                  
                  <div className="mt-6 flex flex-col gap-3">
                     <div className="flex items-center gap-2 text-[10px] text-gray-400 font-black uppercase tracking-widest justify-center">
                        <ShieldCheck size={14} className="text-green-500" />
                        Secure 256-bit SSL Encrypted
                     </div>
                     <div className="flex items-center gap-2 text-[10px] text-gray-400 font-black uppercase tracking-widest justify-center">
                        <AlertCircle size={14} className="text-brand-500" />
                        Money Back Guarantee
                     </div>
                  </div>
               </div>
            </div>

            <div className="bg-brand-500/5 p-4 text-[10px] text-gray-500 italic leading-relaxed text-center">
               <p>By clicking "Complete Purchase", you agree to our <span className="text-brand-500 font-bold cursor-pointer underline">Terms of Service</span> and <span className="text-brand-500 font-bold cursor-pointer underline">Privacy Policy</span>.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
