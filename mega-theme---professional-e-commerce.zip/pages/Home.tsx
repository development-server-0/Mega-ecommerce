
import React, { useState, useEffect, useRef } from 'react';
import { MOCK_PRODUCTS } from '../services/mockData';
import { Product, FORMAT_CURRENCY } from '../types';
import { useNavigate, Link } from 'react-router-dom';
import { 
  ChevronRight, ChevronLeft, Star, Truck, ShieldCheck, Headset, 
  Gift, CreditCard, Wind, Activity, Zap, AlarmClock,
  Heart, ShoppingBag, Eye, Timer, Search, Quote,
  MessageCircle, RefreshCw, LayoutGrid
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

// --- Constants ---
const CATEGORY_ITEMS = [
  { name: 'Electronics', img: 'https://picsum.photos/200/200?random=101' },
  { name: 'Fashion', img: 'https://picsum.photos/200/200?random=102' },
  { name: 'Furniture', img: 'https://picsum.photos/200/200?random=103' },
  { name: 'Baby & Toys', img: 'https://picsum.photos/200/200?random=104' },
  { name: 'Beauty & Care', img: 'https://picsum.photos/200/200?random=105' },
  { name: 'Computing', img: 'https://picsum.photos/200/200?random=106' },
  { name: 'Home & Kitchen', img: 'https://picsum.photos/200/200?random=107' },
  { name: 'Sports', img: 'https://picsum.photos/200/200?random=108' },
];

// --- Helper Functions ---
const openWhatsApp = (e: React.MouseEvent, product: Product) => {
  e.stopPropagation();
  const phoneNumber = "15550123456"; 
  const message = `Hi, I am interested in ${product.name}. Link: ${window.location.origin}/#/product/${product.id}`;
  window.open(`https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`, '_blank');
};

const ServiceBadge = ({ icon: Icon, title, subtitle }: { icon: any, title: string, subtitle: string }) => (
  <div className="flex items-center gap-4 group cursor-pointer p-4 rounded-lg border border-transparent hover:border-brand-500 transition-all duration-300">
    <div className="w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center group-hover:bg-brand-50 transition-colors">
      <Icon size={24} className="text-brand-500" />
    </div>
    <div>
      <h4 className="font-bold text-gray-800 dark:text-white text-sm uppercase tracking-wide">{title}</h4>
      <p className="text-gray-400 text-xs">{subtitle}</p>
    </div>
  </div>
);

const HotDealCard: React.FC<{ product: Product }> = ({ product }) => {
  const navigate = useNavigate();
  const { toggleWishlist, isInWishlist, addToCart } = useStore();
  const isWishlisted = isInWishlist(product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
      e.stopPropagation();
      addToCart(product);
  }

  return (
    <div 
      onClick={() => navigate(`/product/${product.id}`)}
      className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-[0_6px_18px_rgba(0,0,0,0.08)] hover:-translate-y-1 hover:shadow-xl transition-all duration-300 relative group cursor-pointer h-full flex flex-col w-full"
    >
      <div className="absolute top-0 right-0 z-10">
        <div className="bg-brand-500 text-white text-[10px] font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg transform group-hover:scale-110 transition-transform">
          SALE
        </div>
      </div>
      <div className="aspect-[4/3] w-full mb-4 overflow-hidden rounded bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
      </div>
      <div className="text-center flex-1 flex flex-col">
        <h3 className="text-gray-800 dark:text-white font-medium text-sm mb-2 line-clamp-1">{product.name}</h3>
        <div className="flex justify-center gap-1 mb-2">
          {[1,2,3,4,5].map(i => <Star key={i} size={12} className="fill-[#FFD24C] text-[#FFD24C]" />)}
        </div>
        <div className="flex items-center justify-center gap-2 mb-4">
          <span className="text-brand-500 font-bold text-lg">{FORMAT_CURRENCY(product.price)}</span>
          {product.originalPrice && <span className="text-gray-400 text-sm line-through">{FORMAT_CURRENCY(product.originalPrice)}</span>}
        </div>
        <div className="mt-auto grid grid-cols-5 gap-2">
          <button onClick={(e) => { e.stopPropagation(); toggleWishlist(product); }} className={`col-span-1 bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 flex items-center justify-center rounded transition-colors ${isWishlisted ? 'text-brand-500' : 'text-gray-600'}`}><Heart size={16} className={isWishlisted ? "fill-brand-500" : ""} /></button>
          <button onClick={handleAddToCart} className="col-span-3 bg-[#F7F7F7] dark:bg-gray-700 hover:bg-brand-500 hover:text-white text-gray-700 dark:text-white text-xs font-bold py-2 rounded transition-colors uppercase">Add To Cart</button>
          <button onClick={(e) => openWhatsApp(e, product)} className="col-span-1 bg-gray-50 dark:bg-gray-700 hover:bg-[#25D366] hover:text-white flex items-center justify-center rounded text-gray-600 dark:text-white transition-colors" title="Chat on WhatsApp"><MessageCircle size={16} /></button>
        </div>
      </div>
    </div>
  );
};

const CarouselProductCard: React.FC<{ product: Product }> = ({ product }) => {
  const navigate = useNavigate();
  const { toggleWishlist, isInWishlist, addToCart } = useStore();
  const isWishlisted = isInWishlist(product.id);

  const handleQuickView = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/product/quick-view/${product.id}`);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 transition-all duration-300 group cursor-pointer h-full flex flex-col border border-transparent hover:border-gray-100 dark:hover:border-gray-700">
      <div className="relative aspect-square mb-4 overflow-hidden rounded bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <img src={product.image} alt={product.name} className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105" />
        
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button 
            onClick={handleQuickView}
            className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-brand-500 hover:text-white transition-colors text-gray-600"
          >
            <Search size={20} />
          </button>
        </div>

        {product.discount > 0 && (
          <div className="absolute top-2 right-2 bg-brand-500 text-white text-[10px] font-bold px-2 py-1 rounded">
            SALE
          </div>
        )}
      </div>

      <div className="flex-1 flex flex-col">
        <h3 className="text-gray-800 dark:text-white font-medium text-sm mb-2 line-clamp-2 hover:text-brand-500 transition-colors" onClick={() => navigate(`/product/${product.id}`)}>
          {product.name}
        </h3>
        
        <div className="flex gap-0.5 mb-2">
          {[1, 2, 3, 4, 5].map(i => (
            <Star key={i} size={10} className={`${i <= Math.round(product.rating) ? 'fill-[#FFD24C] text-[#FFD24C]' : 'fill-gray-200 text-gray-200'}`} />
          ))}
        </div>

        <div className="flex items-center gap-2 mb-4">
          <span className="text-brand-500 font-bold text-lg">{FORMAT_CURRENCY(product.price)}</span>
          {product.originalPrice && (
            <span className="text-gray-400 text-xs line-through">{FORMAT_CURRENCY(product.originalPrice)}</span>
          )}
        </div>

        <div className="mt-auto grid grid-cols-5 gap-2 pt-2 border-t border-gray-50 dark:border-gray-700">
          <button 
            onClick={(e) => { e.stopPropagation(); toggleWishlist(product); }} 
            className={`col-span-1 flex items-center justify-center rounded hover:text-brand-500 transition-colors ${isWishlisted ? 'text-brand-500' : 'text-gray-400'}`}
          >
            <Heart size={18} className={isWishlisted ? "fill-brand-500" : ""} />
          </button>
          <button 
            onClick={handleAddToCart}
            className="col-span-3 bg-gray-100 dark:bg-gray-700 hover:bg-brand-500 hover:text-white text-gray-700 dark:text-white text-[10px] font-bold py-2.5 rounded transition-all uppercase"
          >
            ADD TO CART
          </button>
          <button 
            onClick={(e) => openWhatsApp(e, product)}
            className="col-span-1 flex items-center justify-center text-gray-400 hover:text-[#25D366] transition-colors"
            title="Chat on WhatsApp"
          >
            <MessageCircle size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

const CategoryShowcaseCarousel = ({ 
  title, 
  products, 
  bannerType 
}: { 
  title: string, 
  products: Product[], 
  bannerType: 'electronics' | 'fashion'
}) => {
  const [scrollIndex, setScrollIndex] = useState(0);
  const navigate = useNavigate();
  const itemsPerPage = 4;
  const totalPages = Math.ceil(products.length / itemsPerPage);

  const handleNext = () => setScrollIndex(prev => (prev + 1) % totalPages);
  const handlePrev = () => setScrollIndex(prev => (prev - 1 + totalPages) % totalPages);

  const renderBanner = () => {
    if (bannerType === 'electronics') {
      return (
        <div 
          onClick={() => navigate('/product')}
          className="md:col-span-3 bg-gradient-to-br from-[#ff708c] to-[#ff4056] rounded-2xl overflow-hidden relative group cursor-pointer flex flex-col p-6 text-white min-h-[400px]"
        >
          <div className="z-10 flex flex-col h-full">
            <span className="bg-white/20 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold w-fit mb-4">4K RESOLUTION</span>
            <h3 className="text-2xl font-black leading-tight mb-2 uppercase italic drop-shadow-sm">
              Sony Selfie <br/> Camera – Capture <br/> All The Moments
            </h3>
            <div className="mt-auto flex justify-center">
              <img src="https://picsum.photos/400/400?random=88" className="w-full h-48 object-contain drop-shadow-2xl group-hover:scale-110 transition-transform duration-500" alt="Sony Camera" />
            </div>
          </div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
        </div>
      );
    }
    return (
      <div 
        onClick={() => navigate('/product')}
        className="md:col-span-3 bg-[#FFD24C] rounded-2xl overflow-hidden relative group cursor-pointer flex flex-col p-6 min-h-[400px]"
      >
        <div className="z-10 flex flex-col h-full text-gray-900">
          <span className="bg-black text-white px-2 py-1 rounded text-[10px] font-bold w-fit mb-4">SPECIAL OFFER</span>
          <h3 className="text-3xl font-black leading-[0.9] mb-4 uppercase">
            60% OFF <br/> <span className="text-lg font-bold">SELECTED ITEM</span>
          </h3>
          <div className="mt-auto relative">
            <img src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=400&q=80" className="w-full h-64 object-cover rounded-xl group-hover:scale-105 transition-transform duration-500" alt="Fashion Model" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#FFD24C]/60 to-transparent"></div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <section className="container mx-auto px-4 py-0">
      <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 p-6 shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white uppercase tracking-tight">{title}</h2>
          <div className="flex items-center gap-4">
            <Link to="/product" className="text-brand-500 font-bold hover:underline flex items-center gap-1 text-xs uppercase tracking-wider">View All</Link>
            <div className="flex gap-2">
              <button onClick={handlePrev} className="w-8 h-8 rounded-full bg-gray-50 dark:bg-gray-700 hover:bg-brand-500 hover:text-white flex items-center justify-center text-gray-400 transition-all shadow-sm"><ChevronLeft size={16} /></button>
              <button onClick={handleNext} className="w-8 h-8 rounded-full bg-gray-50 dark:bg-gray-700 hover:bg-brand-500 hover:text-white flex items-center justify-center text-gray-400 transition-all shadow-sm"><ChevronRight size={16} /></button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
          <div className="md:col-span-9 overflow-hidden relative">
            <div 
              className="flex transition-transform duration-500 ease-in-out" 
              style={{ transform: `translateX(-${scrollIndex * 100}%)` }}
            >
              {Array.from({ length: totalPages }).map((_, pageIdx) => (
                <div key={pageIdx} className="w-full flex-shrink-0 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 px-1">
                  {products.slice(pageIdx * itemsPerPage, (pageIdx + 1) * itemsPerPage).map(p => (
                    <CarouselProductCard key={p.id} product={p} />
                  ))}
                </div>
              ))}
            </div>
          </div>
          {renderBanner()}
        </div>
      </div>
    </section>
  );
};

const ProductPanel = ({ title, products }: { title: string, products: Product[] }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const navigate = useNavigate();
  const { toggleWishlist, isInWishlist, addToCart } = useStore();
  
  const handleNext = () => setCurrentIndex((prev) => (prev + 1) % products.length);
  const handlePrev = () => setCurrentIndex((prev) => (prev - 1 + products.length) % products.length);
  const product = products[currentIndex];
  if (!product) return null;
  const isWishlisted = isInWishlist(product.id);

  return (
    <div className="bg-white dark:bg-gray-800 border border-[#EDEDED] dark:border-gray-700 rounded-2xl p-6 md:p-8 flex flex-col relative transition-all duration-300">
      <span className="absolute top-0 left-0 -translate-x-1 -translate-y-1 bg-brand-500 text-white text-xs font-bold px-4 py-3 min-h-[50px] rounded-br-2xl uppercase tracking-wider z-10 flex items-center justify-center text-center">
        {title}
      </span>

      <div className="flex justify-end items-start mb-6">
        <div className="flex gap-2">
          <button onClick={handlePrev} className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 flex items-center justify-center text-gray-600 dark:text-white transition-colors"><ChevronLeft size={16} /></button>
          <button onClick={handleNext} className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 flex items-center justify-center text-gray-600 dark:text-white transition-colors"><ChevronRight size={16} /></button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start flex-1">
        <div className="relative aspect-square bg-gray-50 dark:bg-gray-900 rounded-lg overflow-hidden flex items-center justify-center p-4">
          <img src={product.image} alt={product.name} className="w-full h-full object-contain hover:scale-105 transition-transform duration-500 cursor-pointer" onClick={() => navigate(`/product/${product.id}`)} />
          {product.discount > 0 && <div className="absolute top-2 left-2 w-10 h-10 bg-brand-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-md">-{product.discount}%</div>}
        </div>

        <div className="flex flex-col h-full justify-start space-y-6 pt-1">
          <h3 className="font-medium text-gray-800 dark:text-white text-lg leading-snug cursor-pointer hover:text-brand-500 transition-colors line-clamp-2" onClick={() => navigate(`/product/${product.id}`)}>
            {product.name}
          </h3>
          
          <div className="flex flex-col space-y-6">
            <div className="flex items-center gap-1">
               {[1,2,3,4,5].map(i => <Star key={i} size={14} className={`${i <= Math.round(product.rating) ? 'fill-[#FFD24C] text-[#FFD24C]' : 'fill-gray-200 text-gray-200'}`} />)}
            </div>
            
            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-bold text-brand-500">{FORMAT_CURRENCY(product.price)}</span>
              {product.originalPrice && <span className="text-sm text-gray-400 line-through decoration-1">{FORMAT_CURRENCY(product.originalPrice)}</span>}
            </div>

            <p className="text-gray-600 dark:text-gray-400 text-sm line-clamp-3 leading-relaxed">
              {product.description}
            </p>
          </div>

          <div className="flex items-center gap-3 mt-4 pt-2">
            <button onClick={(e) => { e.stopPropagation(); addToCart(product); }} className="flex-1 bg-gray-100 dark:bg-gray-700 hover:bg-brand-500 hover:text-white text-gray-700 dark:text-white font-semibold text-xs py-3 px-4 rounded uppercase tracking-wide transition-all duration-300">Add To Cart</button>
            <button onClick={(e) => { e.stopPropagation(); toggleWishlist(product); }} className={`w-10 h-10 border border-gray-200 dark:border-gray-600 rounded flex items-center justify-center hover:text-brand-500 hover:border-brand-500 transition-colors ${isWishlisted ? 'text-brand-500 border-brand-500' : 'text-gray-500'}`}><Heart size={18} className={isWishlisted ? "fill-brand-500" : ""} /></button>
            <button onClick={(e) => openWhatsApp(e, product)} className="w-10 h-10 border border-gray-200 dark:border-gray-600 rounded flex items-center justify-center text-gray-500 hover:text-[#25D366] hover:border-[#25D366] transition-colors" title="Chat on WhatsApp"><MessageCircle size={18} /></button>
          </div>
        </div>
      </div>
    </div>
  );
};

const JustForYou = () => {
  const navigate = useNavigate();
  const { toggleWishlist, isInWishlist, addToCart } = useStore();
  const [displayCount, setDisplayCount] = useState(8);
  const products = MOCK_PRODUCTS.slice(0, displayCount);

  return (
    <section className="container mx-auto px-4 py-12">
      <div className="flex items-center gap-4 mb-8">
        <h2 className="text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tight">Just For You</h2>
        <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700"></div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map(product => (
          <div 
            key={product.id}
            onClick={() => navigate(`/product/${product.id}`)}
            className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-pointer flex flex-col"
          >
            <div className="relative aspect-square mb-4 overflow-hidden rounded-lg bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
              <img src={product.image} alt={product.name} className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-500" />
              {product.discount > 0 && <span className="absolute top-2 right-2 bg-brand-500 text-white text-[10px] font-bold px-2 py-1 rounded">-{product.discount}%</span>}
            </div>
            <div className="flex-1 flex flex-col">
              <h3 className="text-gray-800 dark:text-gray-200 font-medium text-sm mb-1 line-clamp-2 group-hover:text-brand-500 transition-colors">{product.name}</h3>
              <div className="flex items-center gap-1 mb-2">
                {[1, 2, 3, 4, 5].map(i => <Star key={i} size={10} className={`${i <= Math.round(product.rating) ? 'fill-[#FFD24C] text-[#FFD24C]' : 'text-gray-200'}`} />)}
                <span className="text-[10px] text-gray-400">({product.reviews})</span>
              </div>
              <div className="flex items-baseline gap-2 mb-4 mt-auto">
                <span className="text-lg font-bold text-brand-500">{FORMAT_CURRENCY(product.price)}</span>
                {product.originalPrice && <span className="text-xs text-gray-400 line-through">{FORMAT_CURRENCY(product.originalPrice)}</span>}
              </div>
              <div className="grid grid-cols-5 gap-2 pt-3 border-t border-gray-50 dark:border-gray-700">
                <button onClick={(e) => { e.stopPropagation(); toggleWishlist(product); }} className={`col-span-1 border border-gray-100 dark:border-gray-700 rounded flex items-center justify-center h-10 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors ${isInWishlist(product.id) ? 'text-brand-500' : 'text-gray-400'}`}><Heart size={18} className={isInWishlist(product.id) ? "fill-brand-500" : ""} /></button>
                <button onClick={(e) => { e.stopPropagation(); addToCart(product); }} className="col-span-3 bg-gray-800 dark:bg-brand-500 text-white text-[10px] font-bold uppercase rounded h-10 hover:opacity-90 transition-colors">Add to Cart</button>
                <button onClick={(e) => openWhatsApp(e, product)} className="col-span-1 border border-gray-100 dark:border-gray-700 rounded flex items-center justify-center h-10 text-gray-400 hover:text-[#25D366] transition-colors"><MessageCircle size={18} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {displayCount < MOCK_PRODUCTS.length && (
        <div className="mt-12 flex justify-center">
          <button 
            onClick={() => setDisplayCount(prev => prev + 4)}
            className="px-12 py-3 bg-white dark:bg-gray-800 border-2 border-brand-500 text-brand-500 font-bold rounded-lg hover:bg-brand-500 hover:text-white transition-all transform hover:scale-105 active:scale-95 shadow-lg"
          >
            LOAD MORE PRODUCTS
          </button>
        </div>
      )}
    </section>
  );
};

const CountdownBox = ({ val, label }: { val: number, label: string }) => (
  <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-sm p-2 w-16 h-18 flex flex-col items-center justify-center">
    <span className="text-2xl font-bold text-brand-500 leading-none">{val < 10 ? `0${val}` : val}</span>
    <span className="text-[10px] text-gray-400 font-medium uppercase mt-1">{label}</span>
  </div>
);

const HeroSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const slides = [
    {
      title: "ULTRA BOOST",
      mainText: "TERREX",
      subText: "MAGENTECH.COM",
      image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      bgGradient: "from-[#881223] via-[#a31026] to-[#5a0b16]",
      accentColor: "bg-brand-500",
      features: [<Wind size={20}/>, <Activity size={20}/>, <Zap size={20}/>]
    },
    {
      title: "CAPTURE LIFE",
      mainText: "SONY A7",
      subText: "PROFESSIONAL GEAR",
      image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=1000&q=80",
      bgGradient: "from-[#1a2a6c] via-[#b21f1f] to-[#fdbb2d]",
      accentColor: "bg-orange-500",
      features: [<Eye size={20}/>, <Timer size={20}/>, <Gift size={20}/>]
    },
    {
      title: "SUMMER SALE",
      mainText: "FASHION",
      subText: "UP TO 50% OFF",
      image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1000&q=80",
      bgGradient: "from-[#11998e] via-[#38ef7d] to-[#11998e]",
      accentColor: "bg-green-500",
      features: [<ShoppingBag size={20}/>, <Heart size={20}/>, <Star size={20}/>]
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative w-full h-[600px] overflow-hidden">
      {slides.map((slide, index) => (
        <div key={index} className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}>
          <div className={`absolute inset-0 bg-gradient-to-br ${slide.bgGradient}`}></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1)_0%,rgba(0,0,0,0.4)_100%)]"></div>
          <div className="relative container mx-auto h-full px-6 md:px-12 flex flex-col md:flex-row items-center justify-between">
            <div className="hidden md:flex flex-col gap-6 z-10 w-1/4">
              <h3 className="text-white text-3xl font-bold tracking-widest uppercase border-l-4 border-white pl-4">{slide.title.split(' ')[0]}<br/>{slide.title.split(' ')[1] || ''}</h3>
              <div className="flex gap-4 mt-4">{slide.features.map((Icon, i) => <div key={i} className="w-12 h-12 border border-white/30 rounded flex items-center justify-center text-white hover:bg-white/10 transition-colors">{Icon}</div>)}</div>
            </div>
            <div className="flex-1 flex flex-col items-center justify-center z-20 relative top-10 md:top-0">
               <div className="absolute bottom-10 w-[400px] h-[60px] bg-black/40 blur-xl rounded-[100%] scale-y-50"></div>
               <img src={slide.image} alt={slide.mainText} className={`w-[500px] md:w-[700px] object-contain drop-shadow-[0_20px_50px_rgba(0,0,0,0.5)] transition-transform duration-700 ease-out ${index === currentSlide ? 'scale-100 translate-y-0' : 'scale-90 translate-y-10'}`} />
            </div>
            <div className="flex flex-col items-end z-10 w-full md:w-1/3 text-right">
              <h2 className="text-white font-medium text-2xl tracking-[0.2em] mb-0 opacity-90">{slide.title}</h2>
              <h1 className="text-white font-black text-6xl md:text-8xl tracking-tighter leading-[0.85] mb-4">{slide.mainText}</h1>
              <p className="text-white/70 text-sm tracking-[0.3em] font-medium uppercase">{slide.subText}</p>
            </div>
          </div>
        </div>
      ))}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3 z-30">
        {slides.map((_, idx) => <div key={idx} onClick={() => setCurrentSlide(idx)} className={`w-3 h-3 rounded-full cursor-pointer transition-colors ${idx === currentSlide ? 'bg-brand-500 ring-2 ring-brand-500 ring-offset-2 ring-offset-transparent' : 'bg-white/50 hover:bg-white'}`}></div>)}
      </div>
    </section>
  );
};

const PartnerLogos = () => {
    const brands = [
        { name: 'Samsung', url: 'https://upload.wikimedia.org/wikipedia/commons/2/24/Samsung_Logo.svg' },
        { name: 'Intel', url: 'https://upload.wikimedia.org/wikipedia/commons/8/85/Intel_logo_2023.svg' },
        { name: 'Sony', url: 'https://upload.wikimedia.org/wikipedia/commons/c/c3/Sony_logo.svg' },
        { name: 'Asus', url: 'https://upload.wikimedia.org/wikipedia/commons/d/d1/ASUS_Logo.svg' },
        { name: 'LG', url: 'https://upload.wikimedia.org/wikipedia/commons/b/bf/LG_logo_%282015%29.svg' },
        { name: 'Dell', url: 'https://upload.wikimedia.org/wikipedia/commons/4/48/Dell_Logo.svg' },
        { name: 'HP', url: 'https://upload.wikimedia.org/wikipedia/commons/a/ad/HP_logo_2012.svg' }
    ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 py-11 p-8 relative group">
       <div className="flex justify-between items-center px-4">
          <button className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-600 flex-shrink-0"><ChevronLeft size={16}/></button>
          <div className="flex-1 flex justify-between items-center gap-12 overflow-x-auto no-scrollbar px-8">
             {brands.map((brand, i) => <div key={i} className="cursor-pointer flex-shrink-0 hover:scale-110 transition-transform"><img src={brand.url} alt={brand.name} className="h-8 md:h-12 w-auto object-contain" /></div>)}
          </div>
          <button className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-600 flex-shrink-0"><ChevronRight size={16}/></button>
       </div>
    </div>
  )
};

const Testimonials = () => {
    const testimonials = [
        { name: 'Sarah M.', role: 'Verified Buyer', text: 'I ordered the Sony camera and it arrived within 2 days! The packaging was secure and the product quality is amazing.', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80' },
        { name: 'Michael K.', role: 'Loyal Customer', text: 'Just bought a pair of running shoes from the Fashion section. They fit perfectly and are super comfortable.', avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=150&q=80' },
        { name: 'Emily R.', role: 'Verified Buyer', text: 'The best online shopping experience I have had in a while. Great discounts in the Hot Deal section.', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&q=80' },
        { name: 'David W.', role: 'Product Manager', text: 'Excellent service and great quality products. I am very impressed with the delivery speed.', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80' }
    ];
    const [offset, setOffset] = useState(0);
    useEffect(() => {
        const interval = setInterval(() => setOffset(prev => (prev + 1) % testimonials.length), 4000);
        return () => clearInterval(interval);
    }, [testimonials.length]);

    return (
        <div className="p-8 md:p-12 text-center relative overflow-hidden bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
             <div className="absolute top-0 left-8 text-gray-200 dark:text-gray-700 opacity-50 hidden md:block mt-8"><Quote size={80} className="fill-current" /></div>
             <div className="max-w-3xl mx-auto relative z-10 h-[300px]">
                 {testimonials.map((t, i) => (
                    <div key={i} className="absolute inset-0 transition-all duration-700 ease-in-out flex flex-col items-center justify-center bg-transparent" style={{ transform: `translateX(${(i - offset) * 100}%)`, opacity: i === offset ? 1 : 0 }}>
                        <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-8 ring-4 ring-white dark:ring-gray-700 shadow-lg"><img src={t.avatar} alt={t.name} className="w-full h-full object-cover" /></div>
                        <p className="text-gray-700 dark:text-gray-300 italic text-xl leading-relaxed mb-8">"{t.text}"</p>
                        <div>
                            <h4 className="font-bold text-gray-900 dark:text-white uppercase tracking-wide text-lg">{t.name}</h4>
                            <p className="text-brand-500 text-sm font-semibold">{t.role}</p>
                        </div>
                    </div>
                 ))}
             </div>
             <div className="flex justify-center gap-2 mt-4 relative z-20">
                {testimonials.map((_, i) => (
                  <div key={i} className={`w-2 h-2 rounded-full transition-all duration-300 ${i === offset ? 'bg-brand-500 w-4' : 'bg-gray-200 dark:bg-gray-600'}`} />
                ))}
             </div>
        </div>
    )
};

export const Home = () => {
  const { searchQuery, toggleWishlist, isInWishlist, addToCart } = useStore();
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState('All');
  const [timeLeft, setTimeLeft] = useState({ days: 2, hours: 14, mins: 36, secs: 45 });
  const [hotDealIndex, setHotDealIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isCategoryHovered, setIsCategoryHovered] = useState(false);
  const categoryScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { days, hours, mins, secs } = prev;
        if (secs > 0) secs--;
        else { secs = 59; if (mins > 0) mins--; else { mins = 59; if (hours > 0) hours--; else { hours = 23; if (days > 0) days--; } } }
        return { days, hours, mins, secs };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const hotDealItems = MOCK_PRODUCTS.slice(0, 8);
  const itemsVisible = useRef(1);
  
  useEffect(() => {
      const updateItemsVisible = () => {
          if (window.innerWidth >= 1024) itemsVisible.current = 4;
          else if (window.innerWidth >= 640) itemsVisible.current = 2;
          else itemsVisible.current = 1;
      };
      updateItemsVisible();
      window.addEventListener('resize', updateItemsVisible);
      return () => window.removeEventListener('resize', updateItemsVisible);
  }, []);

  const maxIndex = Math.max(0, hotDealItems.length - itemsVisible.current);

  useEffect(() => {
    if(isPaused) return;
    const interval = setInterval(() => {
        setHotDealIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
    }, 3000); 
    return () => clearInterval(interval);
  }, [isPaused, maxIndex]);

  const nextHotDeal = () => setHotDealIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
  const prevHotDeal = () => setHotDealIndex(prev => (prev <= 0 ? maxIndex : prev - 1));

  useEffect(() => {
    const scrollContainer = categoryScrollRef.current;
    if (!scrollContainer) return;
    const scrollStep = 0.5;
    const scrollInterval = setInterval(() => {
        if(scrollContainer && !isCategoryHovered) {
            scrollContainer.scrollLeft += scrollStep;
            if(scrollContainer.scrollLeft >= (scrollContainer.scrollWidth - scrollContainer.clientWidth - 1)) {
                 scrollContainer.scrollLeft = 0;
            }
        }
    }, 30); 
    return () => clearInterval(scrollInterval);
  }, [isCategoryHovered]);

  // Filters for Showcase sections
  const electronicsProducts = MOCK_PRODUCTS.filter(p => p.category === 'Electronics' || p.category === 'Computing');
  // Including more for Fashion section to test slider (adding generic items)
  const fashionProducts = MOCK_PRODUCTS.filter(p => p.category === 'Fashion' || p.category === 'Furniture' || p.category === 'Beauty & Care');

  const newArrivals = MOCK_PRODUCTS.slice(0, 4);
  const bestSelling = [...MOCK_PRODUCTS].reverse().slice(0, 4);
  const featured = MOCK_PRODUCTS.slice(2, 6);
  const onSale = MOCK_PRODUCTS.filter(p => p.discount > 0).slice(0, 4);

  return (
    <div className="flex flex-col pb-12">
      <HeroSlider />
      
      <div className="container mx-auto px-4 py-8 space-y-12">
        {/* Service Badges Section */}
        <section>
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl py-8 px-4 shadow-sm">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
              <ServiceBadge icon={Truck} title="Free Shipping" subtitle="On all orders over $99" />
              <ServiceBadge icon={ShieldCheck} title="Money Guarantee" subtitle="30 Days Money Back" />
              <ServiceBadge icon={Headset} title="Online Support" subtitle="Technical Support 24/7" />
              <ServiceBadge icon={Gift} title="Gift Promotion" subtitle="Free Gift on Sale" />
              <ServiceBadge icon={CreditCard} title="Secure Payment" subtitle="All Cards Accepted" />
            </div>
          </div>
        </section>

        {/* Promo Section */}
        <section>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#E6F4EA] dark:bg-green-900/20 rounded-xl p-8 flex flex-col justify-between h-[280px] relative overflow-hidden group hover:shadow-lg transition-shadow">
              <div className="z-10"><span className="text-green-600 font-bold tracking-wider text-xs uppercase mb-2 block">New Arrivals</span><h3 className="text-3xl font-black text-gray-800 dark:text-white leading-tight mb-2 font-mono">Play In & <br/> Out of water!</h3><button className="mt-4 text-gray-800 dark:text-white font-bold underline hover:text-green-600">Shop Collection</button></div>
              <div className="absolute bottom-0 right-0 w-32 h-32 bg-green-200 dark:bg-green-800/50 rounded-full blur-2xl opacity-50"></div>
              <img src="https://picsum.photos/200/200?random=20" className="absolute bottom-4 right-4 w-32 h-32 object-contain drop-shadow-lg group-hover:scale-110 transition-transform" alt="Toy" />
            </div>
            <div className="bg-[#F3F4F6] dark:bg-gray-800 rounded-xl p-8 flex flex-col items-center text-center justify-center h-[280px] relative group hover:shadow-lg transition-shadow">
               <div className="mb-4"><img src="https://picsum.photos/200/200?random=21" className="w-32 h-32 object-contain mix-blend-multiply dark:mix-blend-screen" alt="Washer" /></div>
               <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-1">Smart Living</h3><p className="text-gray-500 text-sm mb-4">Efficient home appliances</p><button className="bg-gray-800 dark:bg-brand-500 text-white px-6 py-2 rounded-full text-xs font-bold uppercase tracking-wide hover:bg-brand-500 transition-colors">Explore Now</button>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-xl p-8 flex flex-col justify-center h-[280px] relative overflow-hidden group hover:shadow-lg transition-shadow">
              <div className="z-10 relative"><span className="bg-blue-500 text-white text-[10px] font-bold px-2 py-1 rounded mb-3 inline-block">LIMITED EDITION</span><h3 className="text-4xl font-black text-blue-900 dark:text-blue-300 italic mb-1">TYRO</h3><p className="text-blue-700/70 dark:text-blue-400/70 text-sm font-medium mb-4">Next Gen Performance</p><div className="w-10 h-1 bg-blue-500"></div></div>
              <img src="https://picsum.photos/200/200?random=22" className="absolute top-1/2 -translate-y-1/2 right-[-20px] w-40 h-40 object-contain group-hover:-translate-x-2 transition-transform" alt="Product" />
            </div>
          </div>
        </section>

        {/* Hot Deal Section */}
        <section className="bg-brand-500 rounded-2xl p-6 lg:p-10 shadow-xl overflow-hidden relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-4 flex flex-col items-start space-y-4 relative">
              <div className="absolute -top-10 -left-10 text-white opacity-[0.07] pointer-events-none"><AlarmClock size={240} /></div>
              <h2 className="text-white text-3xl font-bold uppercase tracking-wide">Hot Deal</h2>
              <div><p className="text-white/80 text-sm font-medium uppercase tracking-wider mb-1">Sale Up To</p><p className="text-white text-6xl font-black leading-none drop-shadow-md">30% OFF</p></div>
              <p className="text-white text-sm">Hurry up! Offers end in:</p>
              <div className="flex gap-3"><CountdownBox val={timeLeft.days} label="Days" /><CountdownBox val={timeLeft.hours} label="Hours" /><CountdownBox val={timeLeft.mins} label="Mins" /><CountdownBox val={timeLeft.secs} label="Secs" /></div>
            </div>
            <div className="lg:col-span-8 w-full relative group overflow-hidden" onMouseEnter={() => setIsPaused(true)} onMouseLeave={() => setIsPaused(false)}>
               <button onClick={prevHotDeal} className="absolute left-0 top-1/2 -translate-y-1/2 z-20 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center text-gray-700 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-50 -ml-2 sm:ml-0"><ChevronLeft size={20} /></button>
               <button onClick={nextHotDeal} className="absolute right-0 top-1/2 -translate-y-1/2 z-20 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center text-gray-700 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-50 -mr-2 sm:mr-0"><ChevronRight size={20} /></button>
               <div className="flex transition-transform duration-500 ease-in-out" style={{ transform: `translateX(-${hotDealIndex * (100 / itemsVisible.current)}%)` }}>
                    {hotDealItems.map((product, idx) => (
                        <div key={`${product.id}-${idx}`} className="flex-shrink-0 w-full sm:w-1/2 lg:w-1/4 px-2 box-border">
                            <HotDealCard product={product} />
                        </div>
                    ))}
               </div>
            </div>
          </div>
        </section>

        {/* Product Highlight Panels */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <ProductPanel title="New Arrivals" products={newArrivals} />
          <ProductPanel title="Best Selling" products={bestSelling} />
          <ProductPanel title="Featured Products" products={featured} />
          <ProductPanel title="On-Sale Products" products={onSale} />
        </section>
      </div> 

      {/* Shop by Category Strip */}
      <section className="w-full bg-[#1a1a1a] py-16 mt-8 mb-12">
        <div ref={categoryScrollRef} className="container mx-auto px-4 overflow-x-hidden no-scrollbar whitespace-nowrap" onMouseEnter={() => setIsCategoryHovered(true)} onMouseLeave={() => setIsCategoryHovered(false)}>
          <div className="inline-flex gap-8 px-4">
             {[...CATEGORY_ITEMS, ...CATEGORY_ITEMS, ...CATEGORY_ITEMS].map((cat, idx) => (
               <div key={idx} className="flex flex-col items-center gap-4 group cursor-pointer w-[120px] hover:bg-white hover:rounded-xl p-4 transition-all duration-300">
                 <div className="w-[100px] h-[100px] bg-white rounded-full flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform duration-300 overflow-hidden border-4 border-transparent group-hover:border-gray-100"><img src={cat.img} alt={cat.name} className="w-[70%] h-[70%] object-contain" /></div>
                 <span className="text-white text-sm font-medium tracking-wide group-hover:text-gray-900 transition-colors whitespace-normal text-center">{cat.name}</span>
               </div>
             ))}
          </div>
        </div>
      </section>

      {/* Showcase Sections with 10px Gap */}
      <div className="flex flex-col space-y-[10px]">
        {/* Section 1: Electronics */}
        <CategoryShowcaseCarousel 
          title="Electronics" 
          products={electronicsProducts}
          bannerType="electronics"
        />

        {/* Section 2: Fashion & Accessories */}
        <CategoryShowcaseCarousel 
          title="Fashion & Accessories" 
          products={fashionProducts}
          bannerType="fashion"
        />
      </div>

      {/* Just For You Section */}
      <JustForYou />

      <div className="container mx-auto px-4 py-12 space-y-12">
        <PartnerLogos />
        <Testimonials />
      </div>
    </div>
  );
};
