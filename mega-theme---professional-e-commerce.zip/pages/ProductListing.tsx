
import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { MOCK_PRODUCTS } from '../services/mockData';
import { Product, FORMAT_CURRENCY } from '../types';
import { Link, useNavigate } from 'react-router-dom';
import { 
  LayoutGrid, List, ChevronDown, ChevronRight, Star, Heart, 
  MessageCircle, Filter, X, ChevronLeft, Search, SlidersHorizontal
} from 'lucide-react';

const COLORS = [
  { name: 'Black', hex: '#000000' },
  { name: 'Red', hex: '#FF0000' },
  { name: 'Blue', hex: '#0000FF' },
  { name: 'White', hex: '#FFFFFF' },
  { name: 'Gold', hex: '#FFD700' },
];

const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

interface FilterState {
  categories: string[];
  priceRange: { min: number, max: number };
  brands: string[];
  colors: string[];
  sizes: string[];
}

interface SidebarFilterProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  onClose?: () => void;
}

const SidebarFilter: React.FC<SidebarFilterProps> = ({ filters, setFilters, onClose }) => {
  const categories = [
    { name: 'Electronics', count: 6 },
    { name: 'Fashion', count: 2 },
    { name: 'Furniture', count: 1 },
    { name: 'Baby & Toys', count: 1 },
    { name: 'Beauty & Care', count: 1 },
    { name: 'Computing', count: 1 },
  ];

  const toggleCategory = (cat: string) => {
    setFilters(prev => ({
      ...prev,
      categories: prev.categories.includes(cat) ? prev.categories.filter(c => c !== cat) : [...prev.categories, cat]
    }));
  };

  const toggleBrand = (brand: string) => {
    setFilters(prev => ({
      ...prev,
      brands: prev.brands.includes(brand) ? prev.brands.filter(b => b !== brand) : [...prev.brands, brand]
    }));
  };

  const toggleColor = (color: string) => {
    setFilters(prev => ({
      ...prev,
      colors: prev.colors.includes(color) ? prev.colors.filter(c => c !== color) : [...prev.colors, color]
    }));
  };

  const toggleSize = (size: string) => {
    setFilters(prev => ({
      ...prev,
      sizes: prev.sizes.includes(size) ? prev.sizes.filter(s => s !== size) : [...prev.sizes, size]
    }));
  };

  const handlePriceChange = (field: 'min' | 'max', val: string) => {
    const num = val === '' ? 0 : parseInt(val, 10);
    setFilters(prev => ({
      ...prev,
      priceRange: { ...prev.priceRange, [field]: isNaN(num) ? 0 : num }
    }));
  };

  const headerLabelStyle = "font-black text-gray-900 dark:text-white text-[10px] uppercase tracking-[0.2em] mb-4 border-b border-gray-100 dark:border-gray-700 pb-3 flex items-center justify-between";

  return (
    <div className="flex flex-col gap-6">
      <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 dark:border-gray-700">
        <div className="bg-brand-500 text-white px-6 py-5 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <SlidersHorizontal size={18} />
            <span className="font-black uppercase tracking-widest text-xs">Filter Products</span>
          </div>
          {onClose && <X size={20} className="cursor-pointer hover:rotate-90 transition-transform" onClick={onClose} />}
        </div>

        <div className="p-6 space-y-10">
          <section>
            <h4 className={headerLabelStyle}>Category <ChevronDown size={10} className="text-gray-300" /></h4>
            <ul className="space-y-3">
              {categories.map(cat => (
                <li key={cat.name} className="flex justify-between items-center group cursor-pointer" onClick={() => toggleCategory(cat.name)}>
                  <span className={`text-sm transition-colors ${filters.categories.includes(cat.name) ? 'text-brand-500 font-bold' : 'text-gray-500 dark:text-gray-400 group-hover:text-brand-500'}`}>{cat.name}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full transition-colors ${filters.categories.includes(cat.name) ? 'bg-brand-500 text-white' : 'bg-gray-50 dark:bg-gray-700 text-gray-400 group-hover:bg-brand-50'}`}>({cat.count})</span>
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h4 className={headerLabelStyle}>Price Range <ChevronDown size={10} className="text-gray-300" /></h4>
            <div className="space-y-6">
              <input type="range" min="0" max="150000" step="500" className="w-full accent-brand-500 h-1.5 bg-gray-100 rounded-lg appearance-none cursor-pointer" value={filters.priceRange.max} onChange={(e) => handlePriceChange('max', e.target.value)} />
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-gray-50 dark:bg-gray-700 rounded-xl p-2.5 border border-gray-100 dark:border-gray-600">
                  <span className="text-[8px] text-gray-400 block uppercase font-bold mb-1">Min BDT</span>
                  <input type="number" className="w-full bg-transparent text-sm outline-none font-black" value={filters.priceRange.min === 0 ? '' : filters.priceRange.min} placeholder="0" onChange={(e) => handlePriceChange('min', e.target.value)} />
                </div>
                <div className="flex-1 bg-gray-50 dark:bg-gray-700 rounded-xl p-2.5 border border-gray-100 dark:border-gray-600">
                  <span className="text-[8px] text-gray-400 block uppercase font-bold mb-1">Max BDT</span>
                  <input type="number" className="w-full bg-transparent text-sm outline-none font-black" value={filters.priceRange.max === 0 ? '' : filters.priceRange.max} placeholder="150,000" onChange={(e) => handlePriceChange('max', e.target.value)} />
                </div>
              </div>
            </div>
          </section>

          <section>
            <h4 className={headerLabelStyle}>Manufacturer <ChevronDown size={10} className="text-gray-300" /></h4>
            <ul className="space-y-3">
              {['Samsung', 'Sony', 'Intel', 'Generic'].map(brand => (
                <li key={brand} className="flex items-center gap-3 cursor-pointer group" onClick={() => toggleBrand(brand)}>
                  <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${filters.brands.includes(brand) ? 'bg-brand-500 border-brand-500 shadow-lg shadow-brand-500/20' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600'}`}>
                    {filters.brands.includes(brand) && <Check size={12} className="text-white" />}
                  </div>
                  <span className={`text-sm transition-colors ${filters.brands.includes(brand) ? 'text-brand-500 font-bold' : 'text-gray-500 dark:text-gray-400 group-hover:text-brand-500'}`}>{brand}</span>
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h4 className={headerLabelStyle}>Color Selection <ChevronDown size={10} className="text-gray-300" /></h4>
            <div className="flex flex-wrap gap-3">
              {COLORS.map(c => <button key={c.name} onClick={() => toggleColor(c.name)} className={`w-8 h-8 rounded-full border-2 transition-all ${filters.colors.includes(c.name) ? 'ring-4 ring-brand-500/20 scale-110 border-brand-500' : 'border-gray-100 dark:border-gray-700'}`} style={{ backgroundColor: c.hex }} title={c.name} />)}
            </div>
          </section>

          <section>
            <h4 className={headerLabelStyle}>Size <ChevronDown size={10} className="text-gray-300" /></h4>
            <div className="grid grid-cols-3 gap-3">
              {SIZES.map(s => <button key={s} onClick={() => toggleSize(s)} className={`px-2 py-2.5 text-xs font-black rounded-xl border transition-all ${filters.sizes.includes(s) ? 'bg-brand-500 text-white border-brand-500 shadow-lg shadow-brand-500/20' : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 border-gray-100 dark:border-gray-700 hover:border-brand-500 hover:text-brand-500'}`}>{s}</button>)}
            </div>
          </section>
        </div>
        
        <div className="p-6 bg-gray-50 dark:bg-gray-900 border-t border-gray-100 dark:border-gray-700">
           <button onClick={() => setFilters({ categories: [], priceRange: { min: 0, max: 150000 }, brands: [], colors: [], sizes: [] })} className="w-full py-3 bg-white dark:bg-gray-800 border-2 border-brand-500 text-brand-500 font-bold text-xs uppercase tracking-widest rounded-xl hover:bg-brand-500 hover:text-white transition-all active:scale-95">Reset All Filters</button>
        </div>
      </div>
    </div>
  );
};

const Check = ({ size, className }: { size: number, className: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M20 6 9 17l-5-5"/></svg>
);

const ProductCardListing: React.FC<{ product: Product }> = ({ product }) => {
  const navigate = useNavigate();
  const { toggleWishlist, isInWishlist, addToCart } = useStore();
  const isWishlisted = isInWishlist(product.id);

  const handleWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    const phoneNumber = "15550123456"; 
    const message = `Hello! I am interested in ${product.name}. Link: ${window.location.origin}/#/product/${product.id}`;
    window.open(`https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const onAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
  }

  return (
    <div onClick={() => navigate(`/product/${product.id}`)} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-gray-100 dark:border-gray-700 hover:shadow-2xl hover:-translate-y-1.5 transition-all duration-300 group cursor-pointer flex flex-col h-full">
      <div className="relative aspect-square mb-5 overflow-hidden rounded-xl bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
        <img src={product.image} alt={product.name} className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-500" />
        {product.discount > 0 && <span className="absolute top-3 right-3 bg-brand-500 text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-lg shadow-brand-500/20">-{product.discount}% OFF</span>}
      </div>
      <div className="flex-1 flex flex-col">
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">{product.category}</p>
        <h3 className="text-gray-800 dark:text-gray-200 font-bold text-sm mb-2 line-clamp-2 h-10 leading-snug group-hover:text-brand-500 transition-colors">{product.name}</h3>
        <div className="flex items-center gap-1.5 mb-3">
          <div className="flex">
            {[1, 2, 3, 4, 5].map(i => <Star key={i} size={11} className={`${i <= Math.round(product.rating) ? 'fill-[#FFD24C] text-[#FFD24C]' : 'fill-gray-200 text-gray-200'}`} />)}
          </div>
          <span className="text-[10px] text-gray-400 font-bold">({product.reviews} Reviews)</span>
        </div>
        <div className="flex items-baseline gap-2 mb-5 mt-auto">
          <span className="text-xl font-black text-brand-500">{FORMAT_CURRENCY(product.price)}</span>
          {product.originalPrice && <span className="text-xs text-gray-400 line-through font-medium">{FORMAT_CURRENCY(product.originalPrice)}</span>}
        </div>
        <div className="grid grid-cols-4 gap-2 pt-4 border-t border-gray-50 dark:border-gray-700">
          <button onClick={(e) => { e.stopPropagation(); toggleWishlist(product); }} className={`col-span-1 border-2 border-gray-100 dark:border-gray-700 rounded-xl flex items-center justify-center h-11 hover:bg-brand-50 dark:hover:bg-brand-500/10 transition-all ${isWishlisted ? 'text-brand-500 border-brand-500' : 'text-gray-400 hover:text-brand-500'}`}><Heart size={20} className={isWishlisted ? "fill-brand-500" : ""} /></button>
          <button onClick={onAddToCart} className="col-span-2 bg-brand-500 text-white text-[10px] font-black uppercase tracking-widest rounded-xl h-11 hover:bg-brand-600 transition-all shadow-lg shadow-brand-500/20 active:scale-95">Buy Now</button>
          <button onClick={handleWhatsApp} className="col-span-1 border-2 border-gray-100 dark:border-gray-700 rounded-xl flex items-center justify-center h-11 text-gray-400 hover:text-[#25D366] hover:border-[#25D366] transition-all"><MessageCircle size={20} /></button>
        </div>
      </div>
    </div>
  );
};

export const ProductListing = () => {
  const { searchQuery } = useStore();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortBy, setSortBy] = useState('Newest');
  const [itemsPerPage, setItemsPerPage] = useState(12);
  const [currentPage, setCurrentPage] = useState(1);

  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    priceRange: { min: 0, max: 150000 },
    brands: [],
    colors: [],
    sizes: []
  });

  const filteredProductsList = useMemo(() => {
    let result = MOCK_PRODUCTS.filter(p => {
      // Search query filter (Live Search)
      if (searchQuery && 
          !p.name.toLowerCase().includes(searchQuery.toLowerCase()) && 
          !p.category.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      
      if (filters.categories.length > 0 && !filters.categories.includes(p.category)) return false;
      if (filters.priceRange.min > 0 && p.price < filters.priceRange.min) return false;
      if (filters.priceRange.max > 0 && p.price > filters.priceRange.max) return false;
      if (filters.brands.length > 0) {
        const pBrand = p.specs?.Brand || 'Generic';
        if (!filters.brands.includes(pBrand)) return false;
      }
      if (filters.colors.length > 0) {
        const pColor = p.specs?.Color;
        if (!pColor || !filters.colors.includes(pColor)) return false;
      }
      if (filters.sizes.length > 0) {
        const pSize = p.specs?.Size;
        if (!pSize || !filters.sizes.includes(pSize)) return false;
      }
      return true;
    });

    if (sortBy === 'Price (Low to High)') result = [...result].sort((a, b) => a.price - b.price);
    else if (sortBy === 'Price (High to Low)') result = [...result].sort((a, b) => b.price - a.price);
    else if (sortBy === 'Name') result = [...result].sort((a, b) => a.name.localeCompare(b.name));
    else if (sortBy === 'Newest') result = [...result].reverse(); // Mock newest
    return result;
  }, [filters, sortBy, searchQuery]);

  const totalPages = Math.ceil(filteredProductsList.length / itemsPerPage);
  
  const displayedProducts = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredProductsList.slice(start, start + itemsPerPage);
  }, [filteredProductsList, currentPage, itemsPerPage]);

  // Reset page when filters or search change
  useEffect(() => {
    setCurrentPage(1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [filters, sortBy, itemsPerPage, searchQuery]);

  return (
    <div className="bg-gray-50 dark:bg-gray-900 min-h-screen pb-20">
      {/* Listing Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 mb-8 pt-8 pb-10">
        <div className="container mx-auto px-4">
           <nav className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-6">
              <Link to="/" className="hover:text-brand-500 transition-colors">Home</Link>
              <ChevronRight size={10} />
              <span className="text-gray-900 dark:text-white">Shop</span>
           </nav>
           <h1 className="text-4xl md:text-5xl font-black text-gray-900 dark:text-white uppercase tracking-tight mb-2">
             {searchQuery ? `Results for "${searchQuery}"` : 'Collections'}
           </h1>
           <p className="text-gray-400 text-sm font-medium">Discover {filteredProductsList.length} products curated just for you.</p>
        </div>
      </div>

      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-10">
          
          {/* Sidebar Filter - Desktop */}
          <aside className="hidden lg:block w-72 flex-shrink-0 sticky top-32 self-start">
            <SidebarFilter filters={filters} setFilters={setFilters} />
          </aside>

          <div className="flex-1">
            {/* Toolbar */}
            <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] mb-8 flex flex-col sm:flex-row items-center justify-between gap-6 border border-gray-100 dark:border-gray-700">
               <div className="flex items-center gap-6">
                  <button onClick={() => setIsFilterOpen(true)} className="lg:hidden flex items-center gap-2 text-xs font-black uppercase tracking-widest bg-gray-50 dark:bg-gray-700 px-5 py-3 rounded-xl hover:bg-brand-500 hover:text-white transition-all">
                    <Filter size={18} /> Filters
                  </button>
                  <div className="hidden sm:flex items-center gap-1.5 p-1 bg-gray-50 dark:bg-gray-700 rounded-xl">
                     <button onClick={() => setViewMode('grid')} className={`p-2.5 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white dark:bg-gray-800 text-brand-500 shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}><LayoutGrid size={20} /></button>
                     <button onClick={() => setViewMode('list')} className={`p-2.5 rounded-lg transition-all ${viewMode === 'list' ? 'bg-white dark:bg-gray-800 text-brand-500 shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}><List size={20} /></button>
                  </div>
                  <p className="text-[10px] text-gray-400 font-black tracking-widest uppercase hidden md:block">
                    Showing <span className="text-gray-900 dark:text-white">{Math.min(filteredProductsList.length, (currentPage - 1) * itemsPerPage + 1)}-{Math.min(filteredProductsList.length, currentPage * itemsPerPage)}</span> of {filteredProductsList.length} products
                  </p>
               </div>

               <div className="flex items-center gap-6 w-full sm:w-auto">
                  <div className="flex items-center gap-3 flex-1 sm:flex-none">
                     <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest hidden lg:block">Sort</label>
                     <div className="relative flex-1 sm:w-44">
                        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="w-full appearance-none bg-gray-50 dark:bg-gray-700 border-2 border-transparent focus:border-brand-500 rounded-xl px-5 py-3 pr-10 text-xs font-black outline-none transition-all uppercase tracking-widest cursor-pointer">
                           <option>Newest</option>
                           <option>Price (Low to High)</option>
                           <option>Price (High to Low)</option>
                           <option>Name</option>
                        </select>
                        <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400" />
                     </div>
                  </div>
               </div>
            </div>

            {/* Product Grid */}
            {displayedProducts.length > 0 ? (
              <div className={`grid gap-8 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'}`}>
                {displayedProducts.map(product => <ProductCardListing key={product.id} product={product} />)}
              </div>
            ) : (
              <div className="text-center py-32 bg-white dark:bg-gray-800 rounded-3xl border-2 border-dashed border-gray-100 dark:border-gray-700">
                <div className="w-20 h-20 bg-gray-50 dark:bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-200">
                  <Search size={40} />
                </div>
                <h3 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tight mb-2">No items found</h3>
                <p className="text-gray-500 max-w-sm mx-auto mb-8 font-medium">We couldn't find any products matching your current search or filter criteria.</p>
                <button onClick={() => { 
                  setFilters({ categories: [], priceRange: { min: 0, max: 150000 }, brands: [], colors: [], sizes: [] });
                }} className="px-8 py-3.5 bg-brand-500 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl shadow-xl shadow-brand-500/20 hover:bg-brand-600 transition-all active:scale-95">Clear All Search Filters</button>
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-20 flex flex-col md:flex-row items-center justify-between border-t-2 border-gray-100 dark:border-gray-800 pt-12 gap-10">
                <div className="flex items-center gap-3">
                    <button 
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      className="w-12 h-12 bg-white dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 rounded-2xl flex items-center justify-center text-gray-400 hover:text-brand-500 hover:border-brand-500 shadow-sm transition-all disabled:opacity-30 disabled:cursor-not-allowed active:scale-90"
                    >
                      <ChevronLeft size={24} />
                    </button>
                    <div className="flex items-center gap-2">
                      {Array.from({ length: totalPages }).map((_, i) => (
                        <button 
                          key={i}
                          onClick={() => setCurrentPage(i + 1)}
                          className={`w-12 h-12 rounded-2xl font-black text-sm transition-all transform active:scale-90 ${currentPage === i + 1 ? 'bg-brand-500 text-white shadow-xl shadow-brand-500/20 ring-4 ring-brand-500/10' : 'bg-white dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 text-gray-400 hover:text-brand-500 hover:border-brand-500'}`}
                        >
                          {i + 1}
                        </button>
                      ))}
                    </div>
                    <button 
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      className="w-12 h-12 bg-white dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 rounded-2xl flex items-center justify-center text-gray-400 hover:text-brand-500 hover:border-brand-500 shadow-sm transition-all disabled:opacity-30 disabled:cursor-not-allowed active:scale-90"
                    >
                      <ChevronRight size={24} />
                    </button>
                </div>

                <div className="flex items-center gap-4">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Page Size</label>
                    <div className="relative w-40">
                      <select value={itemsPerPage} onChange={(e) => setItemsPerPage(parseInt(e.target.value))} className="w-full appearance-none bg-white dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 rounded-2xl px-5 py-3 pr-10 text-xs font-black outline-none focus:border-brand-500 shadow-sm uppercase tracking-widest cursor-pointer">
                          <option value={12}>12 Products</option>
                          <option value={24}>24 Products</option>
                          <option value={36}>36 Products</option>
                      </select>
                      <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400" />
                    </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Filters Drawer */}
      {isFilterOpen && (
        <div className="fixed inset-0 z-[200] flex">
           <div className="absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity" onClick={() => setIsFilterOpen(false)} />
           <div className="relative w-full max-w-sm bg-white dark:bg-gray-900 h-full overflow-y-auto animate-in slide-in-from-left duration-300">
              <SidebarFilter filters={filters} setFilters={setFilters} onClose={() => setIsFilterOpen(false)} />
           </div>
        </div>
      )}
    </div>
  );
};
