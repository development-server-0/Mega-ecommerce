import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MOCK_PRODUCTS } from '../services/mockData';
import { useStore } from '../context/StoreContext';
import { FORMAT_CURRENCY } from '../types';
import { Star, Heart, Share2, MapPin, ShieldCheck, Truck, Minus, Plus, ChevronLeft, ChevronRight } from 'lucide-react';

export const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useStore();
  const [product, setProduct] = useState(MOCK_PRODUCTS.find(p => p.id === id));
  const [qty, setQty] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Simulating multiple images since mock data only has one
  const images = product ? [
      product.image,
      product.image.replace('random=1', 'random=10').replace('random=2', 'random=12'), // Quick hack to simulate different images based on mock URL pattern if possible, or just reuse
      product.image,
      product.image
  ] : [];

  useEffect(() => {
    const found = MOCK_PRODUCTS.find(p => p.id === id);
    if (found) setProduct(found);
  }, [id]);

  if (!product) return <div className="p-10 text-center">Product not found</div>;

  const handleAddToCart = () => {
    for (let i = 0; i < qty; i++) {
        addToCart(product);
    }
  };

  const handleBuyNow = () => {
      handleAddToCart();
      navigate('/cart');
  }

  const nextImage = () => setCurrentImageIndex((prev) => (prev + 1) % images.length);
  const prevImage = () => setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 md:p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Left: Image Gallery Slider */}
          <div className="md:col-span-1">
            <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden mb-4 group">
              <img src={images[currentImageIndex]} alt={product.name} className="w-full h-full object-cover" />
              
              {/* Slider Arrows */}
              <button 
                onClick={prevImage}
                className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/80 rounded-full flex items-center justify-center hover:bg-white shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <ChevronLeft size={20} />
              </button>
              <button 
                onClick={nextImage}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/80 rounded-full flex items-center justify-center hover:bg-white shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <ChevronRight size={20} />
              </button>
            </div>
            
            <div className="grid grid-cols-4 gap-2">
              {images.map((img, i) => (
                  <div 
                    key={i} 
                    onClick={() => setCurrentImageIndex(i)}
                    className={`aspect-square rounded border cursor-pointer hover:border-brand-500 overflow-hidden ${i === currentImageIndex ? 'border-brand-500 ring-2 ring-brand-500/20' : 'border-gray-200'}`}
                  >
                      <img src={img} className="w-full h-full object-cover opacity-80 hover:opacity-100" />
                  </div>
              ))}
            </div>
          </div>

          {/* Middle: Info */}
          <div className="md:col-span-1 lg:col-span-1 space-y-4">
            <h1 className="text-xl md:text-2xl font-medium text-gray-800 dark:text-white leading-tight">
              {product.name}
            </h1>
            
            <div className="flex items-center gap-4 text-sm">
               <div className="flex items-center gap-1 text-yellow-400">
                  <Star className="fill-current" size={16} />
                  <Star className="fill-current" size={16} />
                  <Star className="fill-current" size={16} />
                  <Star className="fill-current" size={16} />
                  <Star className="fill-current" size={16} />
                  <span className="text-blue-500 ml-1 hover:underline cursor-pointer">{product.reviews} Ratings</span>
               </div>
               <div className="text-gray-300">|</div>
               <span className="text-blue-500 hover:underline cursor-pointer">Brand: Generic</span>
            </div>

            <div className="border-t border-b border-gray-100 dark:border-gray-700 py-4">
              <div className="text-3xl font-bold text-brand-500 mb-1">
                 {FORMAT_CURRENCY(product.price)}
              </div>
              {product.originalPrice && (
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <span className="line-through">{FORMAT_CURRENCY(product.originalPrice)}</span>
                  <span className="text-gray-900 dark:text-white font-bold">-{product.discount}%</span>
                </div>
              )}
            </div>

            <div>
               <span className="text-gray-500 text-sm block mb-2">Color Family</span>
               <div className="flex gap-2">
                 {['Black', 'White', 'Blue'].map(c => (
                   <button key={c} className="px-3 py-1 border border-gray-200 dark:border-gray-600 rounded text-sm hover:border-brand-500">{c}</button>
                 ))}
               </div>
            </div>

            <div className="flex items-center gap-4 pt-4">
               <div className="flex items-center border border-gray-200 dark:border-gray-600 rounded">
                  <button onClick={() => setQty(Math.max(1, qty - 1))} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700"><Minus size={16} /></button>
                  <span className="px-4 font-medium">{qty}</span>
                  <button onClick={() => setQty(qty + 1)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700"><Plus size={16} /></button>
               </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-4">
               <button onClick={handleBuyNow} className="flex-1 bg-brand-500 text-white h-12 rounded shadow-md hover:bg-brand-600 font-semibold text-lg transition-transform active:scale-95">
                  Buy Now
               </button>
               <button onClick={handleAddToCart} className="flex-1 bg-blue-500 text-white h-12 rounded shadow-md hover:bg-blue-600 font-semibold text-lg transition-transform active:scale-95">
                  Add to Cart
               </button>
            </div>
          </div>

          {/* Right: Delivery & Service */}
          <div className="md:col-span-1 bg-gray-50 dark:bg-gray-700/50 rounded p-4 text-sm h-fit">
             <div className="mb-4">
                <span className="text-gray-500 text-xs uppercase font-bold tracking-wider">Delivery</span>
                <div className="mt-3 flex items-start gap-3">
                   <MapPin size={20} className="text-gray-400 mt-0.5" />
                   <div>
                      <p className="font-medium">Dhaka, Bangladesh</p>
                      <p className="text-gray-500 text-xs mt-1">Standard Delivery: 3-5 Days</p>
                      <p className="font-bold mt-1">{FORMAT_CURRENCY(60)}</p>
                   </div>
                </div>
                <div className="mt-3 flex items-start gap-3">
                   <Truck size={20} className="text-gray-400 mt-0.5" />
                   <div>
                      <p className="font-medium">Cash on Delivery Available</p>
                   </div>
                </div>
             </div>
             
             <div className="border-t border-gray-200 dark:border-gray-600 pt-4">
                <span className="text-gray-500 text-xs uppercase font-bold tracking-wider">Service</span>
                <div className="mt-3 flex items-start gap-3">
                   <ShieldCheck size={20} className="text-gray-400 mt-0.5" />
                   <div>
                      <p className="font-medium">7 Days Returns</p>
                      <p className="text-gray-500 text-xs">Change of mind is not applicable</p>
                   </div>
                </div>
                <div className="mt-3 flex items-start gap-3">
                   <ShieldCheck size={20} className="text-gray-400 mt-0.5" />
                   <div>
                      <p className="font-medium">Warranty not available</p>
                   </div>
                </div>
             </div>
          </div>

        </div>

        {/* Product Description */}
        <div className="mt-8 bg-gray-50 dark:bg-gray-700/30 p-6 rounded-lg">
           <h3 className="text-lg font-bold mb-4">Product Details</h3>
           <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
             {product.description}
           </p>
           <h4 className="font-semibold mb-2">Specifications</h4>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-y-2">
              {Object.entries(product.specs).map(([key, value]) => (
                  <div key={key} className="flex border-b border-gray-200 dark:border-gray-700 pb-2">
                      <span className="w-1/3 text-gray-500">{key}</span>
                      <span className="w-2/3 font-medium">{value}</span>
                  </div>
              ))}
           </div>
        </div>
      </div>
    </div>
  );
};