

import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { useNavigate, Link } from 'react-router-dom';

export const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useStore();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(email && password) {
        login(email);
        navigate('/');
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl w-full max-w-md border border-gray-100 dark:border-gray-700">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tight">Login</h2>
            <p className="text-gray-500 text-sm mt-2">Welcome back to Mega Theme!</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Email or Phone Number</label>
              <input 
                type="text" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-transparent transition-all"
                placeholder="Enter your email"
              />
            </div>
            
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Password</label>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-transparent transition-all"
                placeholder="Minimum 6 characters"
              />
            </div>

            <div className="flex items-center justify-end">
               {/* Removed unsupported 'name' prop from Link component */}
               <Link to="/reset-password"  className="text-sm font-semibold text-brand-500 hover:underline">Forgot Password?</Link>
            </div>

            <button 
              type="submit" 
              className="w-full bg-brand-500 text-white py-4 rounded-xl font-bold hover:bg-brand-600 transition-all shadow-lg active:scale-[0.98] uppercase tracking-wider text-sm"
            >
              LOG IN
            </button>
          </form>

          <div className="mt-8 text-center pt-6 border-t border-gray-100 dark:border-gray-700">
            <p className="text-sm text-gray-500 mb-2">Don't have an account?</p>
            <Link to="/register" className="text-brand-500 font-bold hover:underline uppercase tracking-wider text-xs">Create an Account</Link>
          </div>
        </div>
      </div>
    </div>
  );
};
