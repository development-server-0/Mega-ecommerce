
import React from 'react';
import { useStore } from '../context/StoreContext';
import { FORMAT_CURRENCY } from '../types';
import { Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export const Cart = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal, clearCart } = useStore();
  const navigate = useNavigate();
  const SHIPPING_FEE = 120;

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col items-center justify-center py-20 bg-white dark:bg-gray-800 rounded-lg">
          <div className="bg-gray-100 dark:bg-gray-700 p-6 rounded-full mb-4">
            <Trash2 size={48} className="text-gray-400" />
          </div>
          <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-2">Your cart is empty</h2>
          <p className="text-gray-500 mb-6">Looks like you haven't added anything yet.</p>
          <Link to="/" className="bg-brand-500 text-white px-8 py-3 rounded font-medium hover:bg-brand-600 transition-colors">
            Continue Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
             <h1 className="text-xl font-bold">Shopping Cart ({cart.reduce((a,b)=>a+b.quantity,0)} items)</h1>
             <button onClick={clearCart} className="text-red-500 text-sm hover:underline">Remove All</button>
          </div>

          {cart.map((item) => (
            <div key={item.id} className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 flex gap-4">
              <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded bg-gray-100" />
              
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-medium text-gray-800 dark:text-white line-clamp-2">{item.name}</h3>
                  <p className="text-sm text-gray-500 mt-1">Brand: Generic, Color: Default</p>
                </div>
                <div className="flex justify-between items-end mt-2">
                   <div className="text-brand-500 font-bold text-lg">{FORMAT_CURRENCY(item.price)}</div>
                   <div className="flex items-center gap-4">
                      <div className="flex items-center border border-gray-200 dark:border-gray-600 rounded">
                          <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="p-1 px-2 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300">-</button>
                          <span className="px-3 text-sm font-medium">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="p-1 px-2 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300">+</button>
                      </div>
                      <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                          <Trash2 size={18} />
                      </button>
                   </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 sticky top-24">
            <h2 className="text-lg font-bold mb-4">Order Summary</h2>
            
            <div className="space-y-3 text-sm border-b border-gray-200 dark:border-gray-700 pb-4">
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Subtotal</span>
                <span>{FORMAT_CURRENCY(cartTotal)}</span>
              </div>
              <div className="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Shipping Fee</span>
                <span>{FORMAT_CURRENCY(SHIPPING_FEE)}</span>
              </div>
              <div className="flex justify-between items-center mt-4">
                 <input type="text" placeholder="Enter Voucher Code" className="border border-gray-300 dark:border-gray-600 rounded px-3 py-2 text-sm flex-1 mr-2 bg-transparent" />
                 <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium">APPLY</button>
              </div>
            </div>

            <div className="flex justify-between items-center py-4 font-bold text-lg text-gray-800 dark:text-white">
              <span>Total</span>
              <span className="text-brand-500">{FORMAT_CURRENCY(cartTotal + SHIPPING_FEE)}</span>
            </div>

            <button 
              onClick={() => navigate('/checkout')}
              className="w-full bg-brand-500 hover:bg-brand-600 text-white py-3 rounded font-bold shadow-md transition-transform active:scale-95 flex items-center justify-center gap-2"
            >
              PROCEED TO CHECKOUT <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
